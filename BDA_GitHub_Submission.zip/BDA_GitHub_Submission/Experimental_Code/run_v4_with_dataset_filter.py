import os
import pathlib
import runpy

def _norm(x: object) -> str:
    s = str(x).strip().lower()
    s = s.replace("_", "-").replace(" ", "")
    return s

_req = [_norm(s) for s in os.environ.get("BDA_DATASETS", "").split(",") if s.strip()]
_allow = set(_req)
if "severson" in _allow:
    _allow.update(["sev", "severson-et-al", "seversonetal", "severson-et-al."])
if "nasa" in _allow:
    _allow.update(["pcoe", "nasa-pcoe", "nasa_pcoe", "nasa5batterydataset"])
BDA_DATASETS = sorted(_allow)

TRACE = os.environ.get("BDA_TRACE_DATASET_LISTING", "").strip().lower() not in ("", "0", "false", "no")

def _should_filter_root(p) -> bool:
    try:
        pp = str(pathlib.Path(p).resolve())
    except Exception:
        pp = str(p)
    low = pp.lower().replace("/", "\\")
    return (
        low.endswith("\\data\\raw") or low.endswith("\\data\\raw\\") or
        low.endswith("\\data\\processed") or low.endswith("\\data\\processed\\") or
        low.endswith("\\_runs") or low.endswith("\\_runs\\")
    )

def _keep_name(name: str) -> bool:
    return (not BDA_DATASETS) or (_norm(name) in BDA_DATASETS)

def _patch_filesystem_listing():
    if not BDA_DATASETS:
        return

    import os as _os
    _orig_listdir = _os.listdir

    def _listdir(path):
        names = _orig_listdir(path)
        if _should_filter_root(path):
            kept = [n for n in names if _keep_name(n)]
            if TRACE:
                print(f"[BDA] os.listdir filter @ {path} -> {kept}")
            return kept
        return names

    _os.listdir = _listdir

    _orig_iterdir = pathlib.Path.iterdir

    def _iterdir(self):
        it = list(_orig_iterdir(self))
        if _should_filter_root(self):
            kept = [p for p in it if _keep_name(getattr(p, "name", str(p)))]
            if TRACE:
                print(f"[BDA] Path.iterdir filter @ {self} -> {[p.name for p in kept]}")
            return iter(kept)
        return iter(it)

    pathlib.Path.iterdir = _iterdir

_patch_filesystem_listing()

# Execute the original runner as if it were "__main__"
HERE = pathlib.Path(__file__).resolve().parent
RUNNER = HERE / "discovery_v4_ic_early_warning.py"
runpy.run_path(str(RUNNER), run_name="__main__")
