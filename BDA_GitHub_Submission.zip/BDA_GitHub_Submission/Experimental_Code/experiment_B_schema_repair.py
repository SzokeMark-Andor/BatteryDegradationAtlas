import pandas as pd
import os
import glob

# EXPERIMENT B: SCHEMA REPAIR ATTEMPT
# This script attempts to fix the zenodo_matr dataset by aliasing columns.
# Result: Failed to recover usable data (Validation of Recommendation 1).

# Configuration
source_dir = r'../data/processed/within_cell_ic_v4/zenodo_matr'
dest_dir   = r'../data/processed/within_cell_ic_v4/zenodo_matr_SCHEMA_FIX'

# The Aliasing Logic
schema_map = {
    'voltage_in_V': 'voltage_V',
    'charge_capacity_in_Ah': 'capacity_Ah',
    'discharge_capacity_in_Ah': 'capacity_Ah',
    'Qdlin': 'capacity_Ah',
    'time_in_s': 'time_s',
    'current_in_A': 'current_A'
}

if not os.path.exists(dest_dir):
    os.makedirs(dest_dir)

files = glob.glob(os.path.join(source_dir, '**', '*.parquet'), recursive=True)
print(f"Scanning {len(files)} files...")

success = 0
for f in files:
    try:
        df = pd.read_parquet(f)
        df_fixed = df.rename(columns=schema_map)
        
        # Strict V4 Check
        if 'voltage_V' in df_fixed.columns and 'capacity_Ah' in df_fixed.columns:
            base = os.path.basename(f)
            df_fixed.to_parquet(os.path.join(dest_dir, base))
            success += 1
    except:
        pass

print(f"Repair Complete. Recovered: {success} files.")
