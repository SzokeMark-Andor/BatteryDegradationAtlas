# Reproducibility workflow

This package is designed to audit the article-level claims without redistributing raw third-party battery data.

## Quick audit from included processed tables

Create a Python environment:

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Inspect the main processed outputs:

```text
data/stage2F_rest_reference_alignment/stage2F_rest_reference_capacity_analysis_table.csv
data/stage2G_deconfounding/stage2G_v2_deconfounded_correlations.csv
data/stage2G_deconfounding/stage2G_v2_delta_summary_vs_age_baseline.csv
data/protocol_metadata_validation/stage2O_delta_summary_vs_sequence_condition.csv
data/protocol_metadata_validation/stage2O_permutation_null_summary.csv
data/protocol_metadata_validation/stage2O_summary.json
```

The scripts in `scripts/` are included for reproducibility. Depending on local raw-data locations, path variables at the top of the scripts may need adjustment.

## Full raw-data rebuild

A full rebuild requires the original public raw NASA PCoE MAT files, which are intentionally not included in this repository package. After downloading raw data from the official source, rebuild the workflow in this order:

```bash
python scripts/stage2E_v3_step_comment_extraction.py
python scripts/stage2F_rest_reference_alignment.py
python scripts/stage2G_v2_deconfounding.py
python scripts/stage2O_protocol_metadata_validation.py
```

The included processed CSV/JSON outputs are the audited outputs used for the public analysis package.
