# GitHub upload checklist

Recommended upload contents are exactly this package.

Before publishing:

- Add a real license file after selecting the appropriate license.
- Replace `TO_BE_FILLED_AFTER_GITHUB_UPLOAD` in `CITATION.cff` with the final GitHub repository URL.
- Do not upload raw MAT/HDF5 archives to normal Git history.
- Do not upload private correspondence, submission-only reports, or build ZIPs.
- Keep processed CSV/JSON outputs, reproducibility scripts, figures, and documentation.
