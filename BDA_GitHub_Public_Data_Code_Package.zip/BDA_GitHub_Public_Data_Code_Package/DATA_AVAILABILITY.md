# Data availability

This public package contains processed data, analysis scripts, figures, and verification metadata needed to audit the article-level results. Third-party raw battery-cycling archives are not redistributed here; users should obtain raw data from the original public sources and cite those sources separately.

Included processed evidence:

- Stage 2E step-comment and descriptor tables derived from NASA randomized-use cells.
- Stage 2F explicit rest-to-reference-capacity pairing tables.
- Stage 2G deconfounding and leave-one-cell-out prediction outputs.
- Protocol-metadata validation outputs including noise/shuffled controls, permutation-null tests, alternative SOH normalization checks, and condition/sequence baselines.
- Figure assets used for public article and supplementary reporting.

Not included:

- Raw MAT/HDF5 files or other third-party raw archives.
- Private correspondence or submission-only documents.
- Journal submission build packages.
- Broken, superseded, or empty ZIP files.
- Local machine paths, caches, and compiled Python bytecode.

For very large raw datasets, use the original external source, DOI, or dedicated data archive rather than committing raw data to Git history.
