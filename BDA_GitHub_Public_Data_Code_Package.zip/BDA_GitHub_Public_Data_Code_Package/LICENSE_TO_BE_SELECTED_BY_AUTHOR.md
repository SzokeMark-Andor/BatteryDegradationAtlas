# License to be selected by author

Before making this repository public, add a real license file such as `LICENSE`, `LICENSE.md`, or `LICENSE.txt` in the repository root.

Choose the license intentionally. Code and data may require different licensing decisions depending on institutional, journal, and third-party data constraints.

This placeholder is not a license.
