# Stage 2F Explicit Rest-to-Reference-Capacity Report

Generated: 2026-05-05T14:47:19


## Purpose

This stage links explicit `rest prior reference discharge` steps to the immediately following `reference discharge` capacity benchmark. It avoids raw MAT rescanning and uses only Stage 2E v3 derived CSVs.


## Summary

{
  "outdir": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705",
  "stage2E_dir": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304",
  "n_rest_rows_input": 298,
  "n_reference_rows_input": 297,
  "clean_rule_used": "relaxed_fallback",
  "n_clean_rest_rows": 295,
  "n_excluded_rest_rows": 298,
  "n_all_pairs": 295,
  "n_adjacent_pairs_used": 294,
  "n_cells_in_analysis": 16,
  "best_abs_spearman_vs_soh": 0.9496164072703743,
  "best_soh_feature": "rest_sequence_index",
  "has_scipy": true,
  "has_sklearn": true,
  "has_matplotlib": true,
  "outputs": {
    "clean_rest": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_clean_explicit_rest_steps.csv",
    "excluded_rest_audit": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_excluded_rest_steps_for_audit.csv",
    "all_pairs": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_all_rest_reference_pairs.csv",
    "adjacent_pairs": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_adjacent_rest_reference_pairs.csv",
    "analysis_table": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_rest_reference_capacity_analysis_table.csv",
    "correlations": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_rest_capacity_correlations.csv",
    "cell_summary": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_cell_level_summary.csv",
    "prediction": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_leave_cell_out_prediction_metrics.csv",
    "interpretation_flags": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_interpretation_flags.csv",
    "figures": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\figures"
  }
}


## Interpretation flags

| question                                                                     | answer   | evidence                                                                           |
|:-----------------------------------------------------------------------------|:---------|:-----------------------------------------------------------------------------------|
| Do explicit rest-prior-reference steps survive strict cleaning?              | yes      | 295 clean rests retained from 298 rest-prior-reference rows using relaxed_fallback |
| Can clean rests be paired to adjacent reference discharges?                  | yes      | 294 adjacent clean rest-reference pairs                                            |
| Is there a simple rest/reference descriptor correlated with SOH?             | yes      | best |Spearman r| vs reference_soh = 0.950 for rest_sequence_index                 |
| Do rest descriptors improve leave-cell-out SOH prediction over age baseline? | yes      | best age baseline MAE=0.03486; best age+rest MAE=0.03144; delta=-0.00341           |


## Clean-rest filter

Rule used: `relaxed_fallback`. Retained 295 of 298 explicit rest-prior-reference rows. Excluded rows are saved for audit.


## Cell-level summary

| cell_id   |   n_pairs |   initial_reference_capacity_Ah |   final_reference_capacity_Ah |   min_reference_soh |   max_rest_abs_delta_mV |   median_rest_abs_delta_mV |   median_prev_charge_abs_delta_V |   capacity_fade_fraction |
|:----------|----------:|--------------------------------:|------------------------------:|--------------------:|------------------------:|---------------------------:|---------------------------------:|-------------------------:|
| RW13      |        23 |                         2.05534 |                      1.09306  |            0.531813 |                      18 |                        2   |                           0.287  |                 0.468187 |
| RW14      |        24 |                         2.04015 |                      0.879564 |            0.431127 |                       4 |                        2.5 |                           0.265  |                 0.568873 |
| RW15      |        24 |                         2.04503 |                      0.93839  |            0.458864 |                       4 |                        3   |                           0.2565 |                 0.541136 |
| RW16      |        19 |                         1.99224 |                      0.950218 |            0.47696  |                       3 |                        2   |                           0.261  |                 0.52304  |
| RW17      |        28 |                         2.13126 |                      1.0959   |            0.514201 |                       4 |                        2.5 |                           0.2345 |                 0.485799 |
| RW18      |        27 |                         2.11592 |                      1.11675  |            0.520034 |                       3 |                        2   |                           0.219  |                 0.472215 |
| RW19      |        26 |                         2.00329 |                      1.07493  |            0.536583 |                       6 |                        3   |                           0.2505 |                 0.463417 |
| RW20      |        29 |                         2.12921 |                      1.07077  |            0.488782 |                       4 |                        3   |                           0.175  |                 0.497105 |
| RW21      |        11 |                         2.08336 |                      1.64573  |            0.789939 |                       2 |                        1   |                           0.352  |                 0.210061 |
| RW22      |        10 |                         2.07898 |                      1.42295  |            0.684449 |                       4 |                        1   |                           0.316  |                 0.315551 |
| RW23      |        11 |                         2.07089 |                      1.58211  |            0.763978 |                       2 |                        1   |                           0.317  |                 0.236022 |
| RW24      |        11 |                         2.08287 |                      1.66718  |            0.800427 |                       4 |                        1   |                           0.285  |                 0.199573 |
| RW25      |        13 |                         2.06631 |                      1.6749   |            0.810576 |                       2 |                        1   |                           0.272  |                 0.189424 |
| RW26      |        14 |                         2.08179 |                      1.81271  |            0.870745 |                       2 |                        1   |                           0.124  |                 0.129255 |
| RW27      |        12 |                         2.06681 |                      1.74561  |            0.844591 |                       2 |                        1   |                           0.2935 |                 0.155409 |
| RW28      |        12 |                         2.0783  |                      1.74676  |            0.840475 |                       2 |                        1   |                           0.2685 |                 0.159525 |


## Top correlations against reference SOH

| target        | feature                                      |   spearman_r |   pearson_r |   n |   abs_spearman_r |
|:--------------|:---------------------------------------------|-------------:|------------:|----:|-----------------:|
| reference_soh | rest_sequence_index                          |   -0.949616  |  -0.933742  | 294 |        0.949616  |
| reference_soh | rest_delta_voltage_V                         |    0.876256  |   0.641069  | 294 |        0.876256  |
| reference_soh | rest_abs_delta_voltage_V                     |   -0.876256  |  -0.641069  | 294 |        0.876256  |
| reference_soh | rest_abs_delta_voltage_mV                    |   -0.876256  |  -0.641069  | 294 |        0.876256  |
| reference_soh | rest_voltage_end_V                           |    0.866258  |   0.375548  | 294 |        0.866258  |
| reference_soh | prev_charge_median_abs_current_A             |    0.817747  |   0.747623  | 294 |        0.817747  |
| reference_soh | prev_charge_mean_abs_current_A               |    0.780902  |   0.790292  | 294 |        0.780902  |
| reference_soh | prev_charge_capacity_Ah_abs_current_integral |    0.746525  |   0.768082  | 294 |        0.746525  |
| reference_soh | prev_charge_n_points                         |    0.518773  |   0.501282  | 294 |        0.518773  |
| reference_soh | prev_charge_duration_s                       |    0.5187    |   0.501282  | 294 |        0.5187    |
| reference_soh | prev_charge_abs_delta_voltage_V              |    0.388874  |   0.42516   | 294 |        0.388874  |
| reference_soh | prev_charge_delta_voltage_V                  |    0.388684  |   0.424004  | 294 |        0.388684  |
| reference_soh | rest_voltage_start_V                         |    0.0555116 |   0.0475604 | 294 |        0.0555116 |
| reference_soh | rest_duration_s                              |  nan         | nan         | 294 |      nan         |
| reference_soh | rest_n_points                                |  nan         | nan         | 294 |      nan         |
| reference_soh | rest_median_abs_current_A                    |  nan         | nan         | 294 |      nan         |
| reference_soh | rest_mean_abs_current_A                      |  nan         | nan         | 294 |      nan         |


## Leave-cell-out prediction metrics

| status   | feature_set               | model                  |   mae_soh |   rmse_soh |    r2_soh |   n_rows |   n_cells |   n_features |
|:---------|:--------------------------|:-----------------------|----------:|-----------:|----------:|---------:|----------:|-------------:|
| ok       | age_baseline              | ridge                  | 0.0426706 |  0.0542767 | 0.899161  |      294 |        16 |            2 |
| ok       | age_baseline              | random_forest          | 0.0348576 |  0.0479954 | 0.92115   |      294 |        16 |            2 |
| ok       | age_baseline              | hist_gradient_boosting | 0.0388914 |  0.0504535 | 0.912867  |      294 |        16 |            2 |
| ok       | age_plus_rest_descriptors | ridge                  | 0.0401451 |  0.0667489 | 0.847494  |      294 |        16 |           14 |
| ok       | age_plus_rest_descriptors | random_forest          | 0.0314445 |  0.0437554 | 0.934467  |      294 |        16 |           14 |
| ok       | age_plus_rest_descriptors | hist_gradient_boosting | 0.0337124 |  0.0448766 | 0.931065  |      294 |        16 |           14 |
| ok       | rest_only_descriptors     | ridge                  | 0.0708266 |  0.164976  | 0.0683691 |      294 |        16 |           12 |
| ok       | rest_only_descriptors     | random_forest          | 0.0395149 |  0.0532339 | 0.902999  |      294 |        16 |           12 |
| ok       | rest_only_descriptors     | hist_gradient_boosting | 0.0414973 |  0.0552914 | 0.895356  |      294 |        16 |           12 |


## Manuscript interpretation guardrail

A positive result here supports a careful claim that flattening can erase explicit operational-state alignment between rest/reference protocol structure and capacity/SOH benchmarks. It does not by itself prove SEI growth, loss of active material, charge-transfer overpotential, diffusion overpotential, or any single electrochemical degradation mechanism.


## Recommended manuscript language

> In the NASA randomized-use data, explicit step comments expose rest-prior-reference-discharge events and adjacent reference-discharge capacity benchmarks. Filtering these steps provides a structured rest-to-capacity analysis that would be unavailable after flattening or loss of step-state metadata. We therefore interpret the effect as relaxation-state and protocol-semantic information loss, not as direct proof of a specific degradation mechanism.