from pathlib import Path
import json
import math
import warnings
from datetime import datetime

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

REST_CSV = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304\\stage2E_v3_rest_prior_reference_descriptors.csv")
REF_CSV = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304\\stage2E_v3_reference_discharge_descriptors.csv")
TARGET_CSV = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304\\stage2E_v3_target_step_descriptors.csv")
OUTDIR = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705")
OUTDIR.mkdir(parents=True, exist_ok=True)
FIGDIR = OUTDIR / "figures"
FIGDIR.mkdir(exist_ok=True)

try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except Exception:
    HAS_MPL = False

try:
    from scipy.stats import spearmanr, pearsonr
    HAS_SCIPY = True
except Exception:
    HAS_SCIPY = False

try:
    from sklearn.model_selection import GroupKFold
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import Ridge
    from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    HAS_SKLEARN = True
except Exception as e:
    HAS_SKLEARN = False
    SKLEARN_ERROR = str(e)


def bool_series(s):
    return s.astype(str).str.lower().isin(["true", "1", "yes", "y"])


def numeric(df, cols):
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def safe_rmse(y_true, y_pred):
    return float(math.sqrt(mean_squared_error(y_true, y_pred)))


def robust_spearman(x, y):
    x = pd.to_numeric(pd.Series(x), errors="coerce")
    y = pd.to_numeric(pd.Series(y), errors="coerce")
    m = x.notna() & y.notna()
    if m.sum() < 8 or x[m].nunique() < 3 or y[m].nunique() < 3:
        return np.nan
    if HAS_SCIPY:
        return float(spearmanr(x[m], y[m]).correlation)
    return float(x[m].rank().corr(y[m].rank()))


def robust_pearson(x, y):
    x = pd.to_numeric(pd.Series(x), errors="coerce")
    y = pd.to_numeric(pd.Series(y), errors="coerce")
    m = x.notna() & y.notna()
    if m.sum() < 8 or x[m].nunique() < 3 or y[m].nunique() < 3:
        return np.nan
    if HAS_SCIPY:
        return float(pearsonr(x[m], y[m])[0])
    return float(x[m].corr(y[m]))


def prefix_columns(df, prefix, keep):
    out = df.copy()
    rename = {}
    for c in out.columns:
        if c not in keep:
            rename[c] = f"{prefix}{c}"
    return out.rename(columns=rename)


def pair_rest_to_next_reference(clean_rest, ref_df):
    rows = []

    ref_by_cell = {
        cell: g.sort_values("step_index").copy()
        for cell, g in ref_df.groupby("cell_id", sort=False)
    }

    for _, r in clean_rest.sort_values(["cell_id", "step_index"]).iterrows():
        cell = r["cell_id"]
        if cell not in ref_by_cell:
            continue

        candidates = ref_by_cell[cell][ref_by_cell[cell]["step_index"] > r["step_index"]]
        if len(candidates) == 0:
            continue

        ref = candidates.iloc[0]

        row = {}
        for c in clean_rest.columns:
            row[f"rest_{c}"] = r[c]
        for c in ref_df.columns:
            row[f"ref_{c}"] = ref[c]

        row["cell_id"] = cell
        row["rest_step_index"] = int(r["step_index"])
        row["reference_step_index"] = int(ref["step_index"])
        row["steps_to_reference"] = int(ref["step_index"] - r["step_index"])
        row["paired_adjacent_reference"] = bool(row["steps_to_reference"] <= 3)
        rows.append(row)

    return pd.DataFrame(rows)


def run_prediction(df):
    if not HAS_SKLEARN:
        return pd.DataFrame([{
            "status": "skipped",
            "reason": f"scikit-learn unavailable: {SKLEARN_ERROR}"
        }])

    work = df.dropna(subset=["reference_soh", "cell_id"]).copy()
    if len(work) < 40 or work["cell_id"].nunique() < 4:
        return pd.DataFrame([{
            "status": "skipped",
            "reason": "not enough paired rows or cell groups",
            "n_rows": int(len(work)),
            "n_cells": int(work["cell_id"].nunique()) if len(work) else 0
        }])

    feature_sets = {
        "age_baseline": [
            "rest_sequence_index",
            "rest_step_index",
        ],
        "age_plus_rest_descriptors": [
            "rest_sequence_index",
            "rest_step_index",
            "rest_duration_s",
            "rest_n_points",
            "rest_voltage_start_V",
            "rest_voltage_end_V",
            "rest_delta_voltage_V",
            "rest_abs_delta_voltage_V",
            "rest_median_abs_current_A",
            "rest_mean_abs_current_A",
            "prev_charge_duration_s",
            "prev_charge_median_abs_current_A",
            "prev_charge_abs_delta_voltage_V",
            "prev_charge_capacity_Ah_abs_current_integral",
        ],
        "rest_only_descriptors": [
            "rest_duration_s",
            "rest_n_points",
            "rest_voltage_start_V",
            "rest_voltage_end_V",
            "rest_delta_voltage_V",
            "rest_abs_delta_voltage_V",
            "rest_median_abs_current_A",
            "rest_mean_abs_current_A",
            "prev_charge_duration_s",
            "prev_charge_median_abs_current_A",
            "prev_charge_abs_delta_voltage_V",
            "prev_charge_capacity_Ah_abs_current_integral",
        ],
    }

    models = {
        "ridge": make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), Ridge(alpha=1.0)),
        "random_forest": make_pipeline(
            SimpleImputer(strategy="median"),
            RandomForestRegressor(
                n_estimators=300,
                min_samples_leaf=3,
                random_state=42,
                n_jobs=-1
            )
        ),
        "hist_gradient_boosting": HistGradientBoostingRegressor(
            random_state=42,
            max_iter=250,
            learning_rate=0.05
        ),
    }

    rows = []
    y = work["reference_soh"].astype(float)
    groups = work["cell_id"].astype(str)
    n_splits = min(5, groups.nunique())
    cv = GroupKFold(n_splits=n_splits)

    for set_name, cols in feature_sets.items():
        cols = [c for c in cols if c in work.columns]
        if len(cols) < 2:
            rows.append({
                "status": "skipped",
                "feature_set": set_name,
                "reason": "too few available features",
                "n_features": len(cols)
            })
            continue

        X = work[cols].replace([np.inf, -np.inf], np.nan)
        nonempty_cols = [c for c in X.columns if X[c].notna().any()]
        X = X[nonempty_cols]

        if len(X.columns) < 2:
            rows.append({
                "status": "skipped",
                "feature_set": set_name,
                "reason": "too few nonempty features",
                "n_features": len(X.columns)
            })
            continue

        for model_name, model in models.items():
            preds = np.full(len(work), np.nan)

            for train_idx, test_idx in cv.split(X, y, groups):
                model.fit(X.iloc[train_idx], y.iloc[train_idx])
                preds[test_idx] = model.predict(X.iloc[test_idx])

            m = np.isfinite(preds)
            rows.append({
                "status": "ok",
                "feature_set": set_name,
                "model": model_name,
                "mae_soh": float(mean_absolute_error(y[m], preds[m])),
                "rmse_soh": safe_rmse(y[m], preds[m]),
                "r2_soh": float(r2_score(y[m], preds[m])),
                "n_rows": int(m.sum()),
                "n_cells": int(groups.nunique()),
                "n_features": int(len(X.columns))
            })

    return pd.DataFrame(rows)


# -----------------------
# Load Stage 2E v3 outputs
# -----------------------
rest = pd.read_csv(REST_CSV)
ref = pd.read_csv(REF_CSV)
target = pd.read_csv(TARGET_CSV)

for df in [rest, ref, target]:
    for b in [
        "is_rest_prior_reference_discharge",
        "is_charge_after_random_walk_discharge",
        "is_reference_discharge",
        "is_explicit_rest_descriptor_candidate",
    ]:
        if b in df.columns:
            df[b] = bool_series(df[b])

numeric_cols = [
    "step_index", "prev_n_points", "prev_duration_s",
    "prev_median_abs_current_A", "n_points", "duration_s",
    "voltage_start_V", "voltage_end_V", "delta_voltage_V",
    "abs_delta_voltage_V", "voltage_min_V", "voltage_max_V",
    "median_abs_current_A", "mean_abs_current_A",
    "capacity_Ah_abs_current_integral",
    "slope_early_V_per_s", "slope_late_V_per_s"
]
rest = numeric(rest, numeric_cols)
ref = numeric(ref, numeric_cols)
target = numeric(target, numeric_cols)

# -----------------------
# Clean explicit rest filter
# -----------------------
rest["clean_rest_filter"] = (
    (rest["is_rest_prior_reference_discharge"] == True) &
    (rest["is_explicit_rest_descriptor_candidate"] == True) &
    (rest["n_points"] >= 2) &
    (rest["n_points"] <= 20) &
    (rest["duration_s"].between(240, 360, inclusive="both")) &
    (rest["median_abs_current_A"].abs() <= 0.02) &
    (rest["abs_delta_voltage_V"].between(0, 0.02, inclusive="both")) &
    (rest["prev_comment"].astype(str).str.lower().str.contains("charge after random walk discharge", regex=False))
)

clean_rest = rest[rest["clean_rest_filter"]].copy()
excluded_rest = rest[~rest["clean_rest_filter"]].copy()

# If strict rules unexpectedly remove too much, make a documented relaxed backup.
if len(clean_rest) < 50:
    rest["clean_rest_filter_relaxed"] = (
        (rest["is_rest_prior_reference_discharge"] == True) &
        (rest["is_explicit_rest_descriptor_candidate"] == True) &
        (rest["n_points"] >= 2) &
        (rest["duration_s"].between(200, 420, inclusive="both")) &
        (rest["median_abs_current_A"].abs() <= 0.05) &
        (rest["abs_delta_voltage_V"].between(0, 0.05, inclusive="both"))
    )
    clean_rest = rest[rest["clean_rest_filter_relaxed"]].copy()
    clean_rule_used = "relaxed_fallback"
else:
    clean_rule_used = "strict_primary"

clean_rest.to_csv(OUTDIR / "stage2F_clean_explicit_rest_steps.csv", index=False)
excluded_rest.to_csv(OUTDIR / "stage2F_excluded_rest_steps_for_audit.csv", index=False)

# -----------------------
# Pair to next reference discharge
# -----------------------
ref_valid = ref[
    (ref["is_reference_discharge"] == True) &
    (ref["capacity_Ah_abs_current_integral"].between(0.5, 3.0, inclusive="both"))
].copy()

paired = pair_rest_to_next_reference(clean_rest, ref_valid)
paired.to_csv(OUTDIR / "stage2F_all_rest_reference_pairs.csv", index=False)

paired_adj = paired[paired["paired_adjacent_reference"] == True].copy()
paired_adj.to_csv(OUTDIR / "stage2F_adjacent_rest_reference_pairs.csv", index=False)

# -----------------------
# Enrich with previous charge-after-random-walk descriptor
# -----------------------
prev_charge = target[target["is_charge_after_random_walk_discharge"] == True].copy()
prev_charge = prev_charge[
    [
        "cell_id", "step_index", "duration_s", "n_points",
        "voltage_start_V", "voltage_end_V", "delta_voltage_V",
        "abs_delta_voltage_V", "median_abs_current_A",
        "mean_abs_current_A", "capacity_Ah_abs_current_integral"
    ]
].copy()
prev_charge = prev_charge.rename(columns={
    "step_index": "prev_charge_step_index",
    "duration_s": "prev_charge_duration_s",
    "n_points": "prev_charge_n_points",
    "voltage_start_V": "prev_charge_voltage_start_V",
    "voltage_end_V": "prev_charge_voltage_end_V",
    "delta_voltage_V": "prev_charge_delta_voltage_V",
    "abs_delta_voltage_V": "prev_charge_abs_delta_voltage_V",
    "median_abs_current_A": "prev_charge_median_abs_current_A",
    "mean_abs_current_A": "prev_charge_mean_abs_current_A",
    "capacity_Ah_abs_current_integral": "prev_charge_capacity_Ah_abs_current_integral",
})

if len(paired_adj):
    paired_adj["prev_charge_step_index"] = paired_adj["rest_step_index"] - 1
    paired_enriched = paired_adj.merge(
        prev_charge,
        on=["cell_id", "prev_charge_step_index"],
        how="left"
    )
else:
    paired_enriched = paired_adj.copy()

# -----------------------
# Analysis table
# -----------------------
if len(paired_enriched):
    analysis = pd.DataFrame({
        "cell_id": paired_enriched["cell_id"],
        "rest_step_index": paired_enriched["rest_step_index"],
        "reference_step_index": paired_enriched["reference_step_index"],
        "steps_to_reference": paired_enriched["steps_to_reference"],

        "rest_sequence_index": paired_enriched.groupby("cell_id").cumcount(),
        "rest_n_points": paired_enriched["rest_n_points"],
        "rest_duration_s": paired_enriched["rest_duration_s"],
        "rest_voltage_start_V": paired_enriched["rest_voltage_start_V"],
        "rest_voltage_end_V": paired_enriched["rest_voltage_end_V"],
        "rest_delta_voltage_V": paired_enriched["rest_delta_voltage_V"],
        "rest_abs_delta_voltage_V": paired_enriched["rest_abs_delta_voltage_V"],
        "rest_abs_delta_voltage_mV": paired_enriched["rest_abs_delta_voltage_V"] * 1000.0,
        "rest_median_abs_current_A": paired_enriched["rest_median_abs_current_A"],
        "rest_mean_abs_current_A": paired_enriched["rest_mean_abs_current_A"],

        "prev_charge_duration_s": paired_enriched.get("prev_charge_duration_s", np.nan),
        "prev_charge_n_points": paired_enriched.get("prev_charge_n_points", np.nan),
        "prev_charge_delta_voltage_V": paired_enriched.get("prev_charge_delta_voltage_V", np.nan),
        "prev_charge_abs_delta_voltage_V": paired_enriched.get("prev_charge_abs_delta_voltage_V", np.nan),
        "prev_charge_median_abs_current_A": paired_enriched.get("prev_charge_median_abs_current_A", np.nan),
        "prev_charge_mean_abs_current_A": paired_enriched.get("prev_charge_mean_abs_current_A", np.nan),
        "prev_charge_capacity_Ah_abs_current_integral": paired_enriched.get("prev_charge_capacity_Ah_abs_current_integral", np.nan),

        "reference_capacity_Ah": paired_enriched["ref_capacity_Ah_abs_current_integral"],
        "reference_duration_s": paired_enriched["ref_duration_s"],
        "reference_voltage_start_V": paired_enriched["ref_voltage_start_V"],
        "reference_voltage_end_V": paired_enriched["ref_voltage_end_V"],
        "reference_delta_voltage_V": paired_enriched["ref_delta_voltage_V"],
    })

    # Normalize reference discharge capacity within cell to proxy SOH.
    initial = (
        analysis.sort_values(["cell_id", "rest_sequence_index"])
        .groupby("cell_id")["reference_capacity_Ah"]
        .apply(lambda s: float(s.head(min(3, len(s))).median()))
        .rename("initial_reference_capacity_Ah")
        .reset_index()
    )
    analysis = analysis.merge(initial, on="cell_id", how="left")
    analysis["reference_soh"] = analysis["reference_capacity_Ah"] / analysis["initial_reference_capacity_Ah"]
    analysis["reference_capacity_loss_Ah"] = analysis["initial_reference_capacity_Ah"] - analysis["reference_capacity_Ah"]
else:
    analysis = pd.DataFrame()

analysis.to_csv(OUTDIR / "stage2F_rest_reference_capacity_analysis_table.csv", index=False)

# -----------------------
# Correlations
# -----------------------
feature_cols = [
    "rest_sequence_index",
    "rest_duration_s",
    "rest_n_points",
    "rest_voltage_start_V",
    "rest_voltage_end_V",
    "rest_delta_voltage_V",
    "rest_abs_delta_voltage_V",
    "rest_abs_delta_voltage_mV",
    "rest_median_abs_current_A",
    "rest_mean_abs_current_A",
    "prev_charge_duration_s",
    "prev_charge_n_points",
    "prev_charge_delta_voltage_V",
    "prev_charge_abs_delta_voltage_V",
    "prev_charge_median_abs_current_A",
    "prev_charge_mean_abs_current_A",
    "prev_charge_capacity_Ah_abs_current_integral",
]

target_cols = [
    "reference_capacity_Ah",
    "reference_soh",
    "reference_capacity_loss_Ah",
]

corr_rows = []
if len(analysis):
    for target_col in target_cols:
        for feat in feature_cols:
            if feat not in analysis.columns:
                continue
            n = analysis[[feat, target_col]].dropna().shape[0]
            corr_rows.append({
                "target": target_col,
                "feature": feat,
                "spearman_r": robust_spearman(analysis[feat], analysis[target_col]),
                "pearson_r": robust_pearson(analysis[feat], analysis[target_col]),
                "n": int(n),
            })

corr = pd.DataFrame(corr_rows)
if len(corr):
    corr["abs_spearman_r"] = corr["spearman_r"].abs()
    corr = corr.sort_values(["target", "abs_spearman_r"], ascending=[True, False])

corr.to_csv(OUTDIR / "stage2F_rest_capacity_correlations.csv", index=False)

# -----------------------
# Cell-level summary
# -----------------------
if len(analysis):
    cell_summary = (
        analysis.groupby("cell_id")
        .agg(
            n_pairs=("reference_capacity_Ah", "size"),
            initial_reference_capacity_Ah=("initial_reference_capacity_Ah", "first"),
            final_reference_capacity_Ah=("reference_capacity_Ah", "last"),
            min_reference_soh=("reference_soh", "min"),
            max_rest_abs_delta_mV=("rest_abs_delta_voltage_mV", "max"),
            median_rest_abs_delta_mV=("rest_abs_delta_voltage_mV", "median"),
            median_prev_charge_abs_delta_V=("prev_charge_abs_delta_voltage_V", "median"),
        )
        .reset_index()
    )
    cell_summary["capacity_fade_fraction"] = 1.0 - (
        cell_summary["final_reference_capacity_Ah"] /
        cell_summary["initial_reference_capacity_Ah"]
    )
else:
    cell_summary = pd.DataFrame()

cell_summary.to_csv(OUTDIR / "stage2F_cell_level_summary.csv", index=False)

# -----------------------
# Prediction
# -----------------------
prediction = run_prediction(analysis)
prediction.to_csv(OUTDIR / "stage2F_leave_cell_out_prediction_metrics.csv", index=False)

# -----------------------
# Figures
# -----------------------
if HAS_MPL:
    if len(analysis):
        plt.figure(figsize=(10, 6))
        for cell, g in analysis.groupby("cell_id"):
            g = g.sort_values("rest_sequence_index")
            plt.plot(g["rest_sequence_index"], g["reference_capacity_Ah"], marker="o", linewidth=1, markersize=3, label=cell)
        plt.xlabel("Reference-discharge sequence index")
        plt.ylabel("Reference-discharge capacity (Ah)")
        plt.title("NASA RW reference-discharge capacity linked to explicit prior rest")
        plt.legend(fontsize=7, ncol=2)
        plt.tight_layout()
        plt.savefig(FIGDIR / "fig_stage2F_reference_capacity_trajectories.png", dpi=200)
        plt.close()

        plt.figure(figsize=(8, 5))
        plt.scatter(analysis["rest_abs_delta_voltage_mV"], analysis["reference_soh"], s=18, alpha=0.75)
        plt.xlabel("|ΔV| during clean explicit rest (mV)")
        plt.ylabel("Reference SOH proxy")
        plt.title("Clean explicit rest voltage descriptor vs reference SOH")
        plt.tight_layout()
        plt.savefig(FIGDIR / "fig_stage2F_rest_deltaV_vs_soh.png", dpi=200)
        plt.close()

        plt.figure(figsize=(8, 5))
        plt.scatter(analysis["prev_charge_abs_delta_voltage_V"], analysis["reference_soh"], s=18, alpha=0.75)
        plt.xlabel("|ΔV| in preceding charge-after-RW step (V)")
        plt.ylabel("Reference SOH proxy")
        plt.title("Pre-reference charge descriptor vs reference SOH")
        plt.tight_layout()
        plt.savefig(FIGDIR / "fig_stage2F_prev_charge_deltaV_vs_soh.png", dpi=200)
        plt.close()

    if len(corr):
        top = corr[corr["target"] == "reference_soh"].dropna(subset=["abs_spearman_r"]).head(20).copy()
        if len(top):
            plt.figure(figsize=(10, 5))
            plt.bar(top["feature"], top["abs_spearman_r"])
            plt.xticks(rotation=45, ha="right")
            plt.ylabel("|Spearman r| vs reference SOH")
            plt.title("Top Stage 2F rest/reference descriptor correlations")
            plt.tight_layout()
            plt.savefig(FIGDIR / "fig_stage2F_top_correlations.png", dpi=200)
            plt.close()

    if len(prediction) and "mae_soh" in prediction.columns:
        ok = prediction[prediction["status"] == "ok"].copy()
        if len(ok):
            ok["label"] = ok["feature_set"] + " / " + ok["model"]
            plt.figure(figsize=(10, 5))
            plt.bar(ok["label"], ok["mae_soh"])
            plt.xticks(rotation=45, ha="right")
            plt.ylabel("Leave-cell-out MAE on reference SOH")
            plt.title("Stage 2F downstream prediction: baseline vs rest descriptors")
            plt.tight_layout()
            plt.savefig(FIGDIR / "fig_stage2F_prediction_mae.png", dpi=200)
            plt.close()

# -----------------------
# Interpretation flags
# -----------------------
if len(corr):
    soh_corr = corr[corr["target"] == "reference_soh"].dropna(subset=["abs_spearman_r"])
    best_soh_corr = float(soh_corr["abs_spearman_r"].max()) if len(soh_corr) else np.nan
    best_soh_feature = str(soh_corr.iloc[0]["feature"]) if len(soh_corr) else ""
else:
    best_soh_corr = np.nan
    best_soh_feature = ""

if len(prediction) and "mae_soh" in prediction.columns:
    ok_pred = prediction[prediction["status"] == "ok"].copy()
    baseline = ok_pred[ok_pred["feature_set"] == "age_baseline"]["mae_soh"].min() if len(ok_pred[ok_pred["feature_set"] == "age_baseline"]) else np.nan
    plus_rest = ok_pred[ok_pred["feature_set"] == "age_plus_rest_descriptors"]["mae_soh"].min() if len(ok_pred[ok_pred["feature_set"] == "age_plus_rest_descriptors"]) else np.nan
    prediction_delta_mae = float(plus_rest - baseline) if pd.notna(baseline) and pd.notna(plus_rest) else np.nan
else:
    baseline = np.nan
    plus_rest = np.nan
    prediction_delta_mae = np.nan

interpretation = pd.DataFrame([
    {
        "question": "Do explicit rest-prior-reference steps survive strict cleaning?",
        "answer": "yes" if len(clean_rest) >= 50 else "weak",
        "evidence": f"{len(clean_rest)} clean rests retained from {len(rest)} rest-prior-reference rows using {clean_rule_used}"
    },
    {
        "question": "Can clean rests be paired to adjacent reference discharges?",
        "answer": "yes" if len(analysis) >= 50 else "weak",
        "evidence": f"{len(analysis)} adjacent clean rest-reference pairs"
    },
    {
        "question": "Is there a simple rest/reference descriptor correlated with SOH?",
        "answer": "yes" if pd.notna(best_soh_corr) and best_soh_corr >= 0.30 else "weak/no",
        "evidence": f"best |Spearman r| vs reference_soh = {best_soh_corr:.3f} for {best_soh_feature}" if pd.notna(best_soh_corr) else "no valid correlation"
    },
    {
        "question": "Do rest descriptors improve leave-cell-out SOH prediction over age baseline?",
        "answer": "yes" if pd.notna(prediction_delta_mae) and prediction_delta_mae < -0.001 else "no/unclear",
        "evidence": f"best age baseline MAE={baseline:.5f}; best age+rest MAE={plus_rest:.5f}; delta={prediction_delta_mae:.5f}" if pd.notna(prediction_delta_mae) else "prediction skipped or incomplete"
    },
])

interpretation.to_csv(OUTDIR / "stage2F_interpretation_flags.csv", index=False)

# -----------------------
# Markdown report
# -----------------------
summary = {
    "outdir": str(OUTDIR),
    "stage2E_dir": str(REST_CSV.parent),
    "n_rest_rows_input": int(len(rest)),
    "n_reference_rows_input": int(len(ref)),
    "clean_rule_used": clean_rule_used,
    "n_clean_rest_rows": int(len(clean_rest)),
    "n_excluded_rest_rows": int(len(excluded_rest)),
    "n_all_pairs": int(len(paired)),
    "n_adjacent_pairs_used": int(len(analysis)),
    "n_cells_in_analysis": int(analysis["cell_id"].nunique()) if len(analysis) else 0,
    "best_abs_spearman_vs_soh": None if pd.isna(best_soh_corr) else best_soh_corr,
    "best_soh_feature": best_soh_feature,
    "has_scipy": HAS_SCIPY,
    "has_sklearn": HAS_SKLEARN,
    "has_matplotlib": HAS_MPL,
    "outputs": {
        "clean_rest": str(OUTDIR / "stage2F_clean_explicit_rest_steps.csv"),
        "excluded_rest_audit": str(OUTDIR / "stage2F_excluded_rest_steps_for_audit.csv"),
        "all_pairs": str(OUTDIR / "stage2F_all_rest_reference_pairs.csv"),
        "adjacent_pairs": str(OUTDIR / "stage2F_adjacent_rest_reference_pairs.csv"),
        "analysis_table": str(OUTDIR / "stage2F_rest_reference_capacity_analysis_table.csv"),
        "correlations": str(OUTDIR / "stage2F_rest_capacity_correlations.csv"),
        "cell_summary": str(OUTDIR / "stage2F_cell_level_summary.csv"),
        "prediction": str(OUTDIR / "stage2F_leave_cell_out_prediction_metrics.csv"),
        "interpretation_flags": str(OUTDIR / "stage2F_interpretation_flags.csv"),
        "figures": str(FIGDIR),
    }
}

with open(OUTDIR / "stage2F_summary.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

report = []
report.append("# Stage 2F Explicit Rest-to-Reference-Capacity Report\n")
report.append(f"Generated: {datetime.now().isoformat(timespec='seconds')}\n")
report.append("\n## Purpose\n")
report.append("This stage links explicit `rest prior reference discharge` steps to the immediately following `reference discharge` capacity benchmark. It avoids raw MAT rescanning and uses only Stage 2E v3 derived CSVs.\n")
report.append("\n## Summary\n")
report.append(json.dumps(summary, indent=2))
report.append("\n\n## Interpretation flags\n")
report.append(interpretation.to_markdown(index=False))
report.append("\n\n## Clean-rest filter\n")
report.append(f"Rule used: `{clean_rule_used}`. Retained {len(clean_rest)} of {len(rest)} explicit rest-prior-reference rows. Excluded rows are saved for audit.\n")
report.append("\n## Cell-level summary\n")
report.append(cell_summary.to_markdown(index=False) if len(cell_summary) else "No cell summary available.")
report.append("\n\n## Top correlations against reference SOH\n")
if len(corr):
    report.append(corr[corr["target"] == "reference_soh"].head(25).to_markdown(index=False))
else:
    report.append("No correlations available.")
report.append("\n\n## Leave-cell-out prediction metrics\n")
report.append(prediction.to_markdown(index=False) if len(prediction) else "No prediction metrics available.")
report.append("\n\n## Manuscript interpretation guardrail\n")
report.append("A positive result here supports a careful claim that flattening can erase explicit operational-state alignment between rest/reference protocol structure and capacity/SOH benchmarks. It does not by itself prove SEI growth, loss of active material, charge-transfer overpotential, diffusion overpotential, or any single electrochemical degradation mechanism.")
report.append("\n\n## Recommended manuscript language\n")
report.append("> In the NASA randomized-use data, explicit step comments expose rest-prior-reference-discharge events and adjacent reference-discharge capacity benchmarks. Filtering these steps provides a structured rest-to-capacity analysis that would be unavailable after flattening or loss of step-state metadata. We therefore interpret the effect as relaxation-state and protocol-semantic information loss, not as direct proof of a specific degradation mechanism.")

(OUTDIR / "stage2F_rest_to_capacity_report.md").write_text("\n".join(report), encoding="utf-8")

print("\n=== STAGE 2F SUMMARY ===")
print(json.dumps(summary, indent=2))

print("\n=== INTERPRETATION FLAGS ===")
print(interpretation.to_string(index=False))

print("\n=== CELL SUMMARY ===")
print(cell_summary.to_string(index=False) if len(cell_summary) else "No cell summary.")

print("\n=== TOP CORRELATIONS VS REFERENCE SOH ===")
if len(corr):
    print(corr[corr["target"] == "reference_soh"].head(25).to_string(index=False))
else:
    print("No correlations.")

print("\n=== PREDICTION METRICS ===")
print(prediction.to_string(index=False) if len(prediction) else "No prediction metrics.")

print("\nDONE")
print(OUTDIR)
