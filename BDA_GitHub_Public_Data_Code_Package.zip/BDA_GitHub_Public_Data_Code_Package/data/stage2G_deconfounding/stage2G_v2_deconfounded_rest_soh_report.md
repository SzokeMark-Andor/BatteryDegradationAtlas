# Stage 2G v2 Deconfounded Rest-to-SOH Robustness Report

Generated: 2026-05-05T14:54:52


## Summary

{
  "outdir": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2G_v2_deconfounded_rest_soh_20260505_145323",
  "stage2F_dir": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705",
  "analysis_csv": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_rest_reference_capacity_analysis_table.csv",
  "n_rows": 294,
  "n_cells": 16,
  "best_raw_abs_spearman": 0.8762560111344652,
  "best_raw_feature": "rest_delta_voltage_V",
  "best_sequence_residual_abs_spearman": 0.12306310156387425,
  "best_sequence_residual_feature": "rest_delta_voltage_V",
  "best_first_difference_abs_spearman": 0.17814974634711586,
  "best_first_difference_feature": "prev_charge_abs_delta_voltage_V",
  "best_age_plus_rest_delta_mae": -0.00888764734278065,
  "best_age_plus_rest_label": "age_plus_rest_plus_charge / ridge",
  "best_noise_control_delta_mae": 0.0006452166077865909,
  "best_shuffled_control_delta_mae": -0.0021329397961494983,
  "manuscript_strength": "weak_to_moderate_predictive_increment",
  "has_scipy": true,
  "has_sklearn": true,
  "has_matplotlib": true,
  "outputs": {
    "correlations": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2G_v2_deconfounded_rest_soh_20260505_145323\\stage2G_v2_deconfounded_correlations.csv",
    "prediction_summary": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2G_v2_deconfounded_rest_soh_20260505_145323\\stage2G_v2_leave_one_cell_out_prediction_summary.csv",
    "fold_metrics": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2G_v2_deconfounded_rest_soh_20260505_145323\\stage2G_v2_leave_one_cell_out_fold_metrics.csv",
    "delta_summary": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2G_v2_deconfounded_rest_soh_20260505_145323\\stage2G_v2_delta_summary_vs_age_baseline.csv",
    "condition_summary": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2G_v2_deconfounded_rest_soh_20260505_145323\\stage2G_v2_condition_group_summary.csv",
    "interpretation_flags": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2G_v2_deconfounded_rest_soh_20260505_145323\\stage2G_v2_interpretation_flags.csv",
    "figures": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2G_v2_deconfounded_rest_soh_20260505_145323\\figures"
  }
}


## Interpretation flags

| question                                                                  | answer                                | evidence                                                                     |
|:--------------------------------------------------------------------------|:--------------------------------------|:-----------------------------------------------------------------------------|
| Does raw descriptor correlation with SOH exist?                           | yes                                   | best raw |Spearman r|=0.876 for rest_delta_voltage_V                         |
| Does descriptor correlation survive within-cell sequence residualization? | weak/no                               | best residual |Spearman r|=0.123 for rest_delta_voltage_V                    |
| Does first-difference analysis support local descriptor-to-SOH changes?   | weak/no                               | best first-difference |Spearman r|=0.178 for prev_charge_abs_delta_voltage_V |
| Does age+rest improve leave-one-cell-out prediction over age baseline?    | yes                                   | best delta=-0.00889; improved folds=0.81; age_plus_rest_plus_charge / ridge  |
| Does age+rest beat noise and shuffled-descriptor controls?                | yes                                   | rest delta=-0.00889; noise delta=0.00065; shuffled delta=-0.00213            |
| Recommended manuscript strength                                           | weak_to_moderate_predictive_increment | Use this as the Stage 2G public reproducibility strength label.                   |


## Top sequence-residual correlations

| method                                  | feature                                      | target        |   spearman_r |   pearson_r |   n |   abs_spearman_r |
|:----------------------------------------|:---------------------------------------------|:--------------|-------------:|------------:|----:|-----------------:|
| within_cell_quadratic_sequence_residual | rest_delta_voltage_V                         | reference_soh |   0.123063   |   0.208985  | 294 |       0.123063   |
| within_cell_quadratic_sequence_residual | rest_abs_delta_voltage_V                     | reference_soh |  -0.123063   |  -0.208985  | 294 |       0.123063   |
| within_cell_quadratic_sequence_residual | rest_abs_delta_voltage_mV                    | reference_soh |  -0.123063   |  -0.208985  | 294 |       0.123063   |
| within_cell_quadratic_sequence_residual | rest_voltage_end_V                           | reference_soh |   0.0924831  |   0.186945  | 294 |       0.0924831  |
| within_cell_quadratic_sequence_residual | prev_charge_delta_voltage_V                  | reference_soh |  -0.0915594  |  -0.141503  | 294 |       0.0915594  |
| within_cell_quadratic_sequence_residual | prev_charge_abs_delta_voltage_V              | reference_soh |  -0.0901017  |  -0.140762  | 294 |       0.0901017  |
| within_cell_quadratic_sequence_residual | prev_charge_median_abs_current_A             | reference_soh |   0.0491276  |  -0.109429  | 294 |       0.0491276  |
| within_cell_quadratic_sequence_residual | prev_charge_capacity_Ah_abs_current_integral | reference_soh |   0.0432452  |  -0.0327497 | 294 |       0.0432452  |
| within_cell_quadratic_sequence_residual | prev_charge_n_points                         | reference_soh |  -0.0167546  |  -0.0129127 | 294 |       0.0167546  |
| within_cell_quadratic_sequence_residual | rest_voltage_start_V                         | reference_soh |   0.0165323  |   0.161076  | 294 |       0.0165323  |
| within_cell_quadratic_sequence_residual | prev_charge_duration_s                       | reference_soh |  -0.0158021  |  -0.0122565 | 294 |       0.0158021  |
| within_cell_quadratic_sequence_residual | prev_charge_mean_abs_current_A               | reference_soh |  -0.00395602 |  -0.130536  | 294 |       0.00395602 |


## Prediction delta summary vs age baseline

| feature_set                          | model                  |   n_folds |   mean_delta_mae_vs_age |   median_delta_mae_vs_age |   fraction_folds_improved |   wilcoxon_p_less_than_age |
|:-------------------------------------|:-----------------------|----------:|------------------------:|--------------------------:|--------------------------:|---------------------------:|
| age_plus_charge                      | hist_gradient_boosting |        16 |            -0.00557497  |              -0.00279942  |                    0.625  |                  0.0253296 |
| age_plus_charge                      | random_forest          |        16 |            -0.00450819  |              -0.00216591  |                    0.625  |                  0.0719299 |
| age_plus_charge                      | ridge                  |        16 |            -0.00661099  |              -0.00741302  |                    0.75   |                  0.0144958 |
| age_plus_noise_control               | hist_gradient_boosting |        16 |             0.0054427   |               0.00605545  |                    0.3125 |                  0.987518  |
| age_plus_noise_control               | random_forest          |        16 |             0.00484245  |               0.00387492  |                    0.25   |                  0.996857  |
| age_plus_noise_control               | ridge                  |        16 |             0.000645217 |               0.00108748  |                    0.4375 |                  0.701706  |
| age_plus_rest                        | hist_gradient_boosting |        16 |             0.000203345 |              -0.00108607  |                    0.5625 |                  0.56987   |
| age_plus_rest                        | random_forest          |        16 |             0.000744238 |               0.000166944 |                    0.5    |                  0.589554  |
| age_plus_rest                        | ridge                  |        16 |            -0.00285877  |              -0.00301403  |                    0.75   |                  0.0253296 |
| age_plus_rest_plus_charge            | hist_gradient_boosting |        16 |            -0.00536745  |              -0.00218749  |                    0.625  |                  0.0648651 |
| age_plus_rest_plus_charge            | random_forest          |        16 |            -0.00453258  |              -0.00275984  |                    0.6875 |                  0.0648651 |
| age_plus_rest_plus_charge            | ridge                  |        16 |            -0.00888765  |              -0.0100864   |                    0.8125 |                  0.0106964 |
| age_plus_shuffled_descriptor_control | hist_gradient_boosting |        16 |            -0.000601423 |               0.000649975 |                    0.4375 |                  0.56987   |
| age_plus_shuffled_descriptor_control | random_forest          |        16 |             0.000330844 |               0.00011755  |                    0.5    |                  0.56987   |
| age_plus_shuffled_descriptor_control | ridge                  |        16 |            -0.00213294  |              -0.00520788  |                    0.75   |                  0.174194  |
| charge_only_no_age                   | hist_gradient_boosting |        16 |             0.0170781   |               0.0199288   |                    0.25   |                  0.997421  |
| charge_only_no_age                   | random_forest          |        16 |             0.0155642   |               0.0184269   |                    0.25   |                  0.997421  |
| charge_only_no_age                   | ridge                  |        16 |             0.028662    |               0.0361367   |                    0.125  |                  0.999344  |
| rest_only_no_age                     | hist_gradient_boosting |        16 |             0.0283295   |               0.0356607   |                    0.0625 |                  0.999924  |
| rest_only_no_age                     | random_forest          |        16 |             0.0280086   |               0.0332054   |                    0.1875 |                  0.999847  |
| rest_only_no_age                     | ridge                  |        16 |             0.0398295   |               0.041586    |                    0      |                  1         |
| rest_plus_charge_no_age              | hist_gradient_boosting |        16 |             0.00339391  |               0.0052947   |                    0.3125 |                  0.838745  |
| rest_plus_charge_no_age              | random_forest          |        16 |             0.00502228  |               0.0087919   |                    0.25   |                  0.851074  |
| rest_plus_charge_no_age              | ridge                  |        16 |             0.0169982   |               0.0183044   |                    0.1875 |                  0.99971   |


## Public-validation-safe interpretation

The result supports a weak-to-moderate predictive increment; emphasize metadata preservation and prognostic alignment.


## Suggested manuscript sentence

> Deconfounding analyses show that explicit rest/reference step metadata is necessary to align randomized-use intervals with reference-capacity benchmarks. The strongest signal is expected to track aging/protocol sequence, while rest and pre-reference descriptors are interpreted as structured operational-state information rather than direct evidence for a specific electrochemical degradation mechanism.