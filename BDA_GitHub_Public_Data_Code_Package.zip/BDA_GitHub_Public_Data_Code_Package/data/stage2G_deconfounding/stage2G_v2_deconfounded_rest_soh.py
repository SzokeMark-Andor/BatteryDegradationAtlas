from pathlib import Path
import json
import math
import warnings
from datetime import datetime

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

ANALYSIS_CSV = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_rest_reference_capacity_analysis_table.csv")
OUTDIR = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2G_v2_deconfounded_rest_soh_20260505_145323")
OUTDIR.mkdir(parents=True, exist_ok=True)
FIGDIR = OUTDIR / "figures"
FIGDIR.mkdir(exist_ok=True)

RNG = np.random.default_rng(42)

try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except Exception:
    HAS_MPL = False

try:
    from scipy.stats import spearmanr, pearsonr, wilcoxon
    HAS_SCIPY = True
except Exception:
    HAS_SCIPY = False

try:
    from sklearn.base import clone
    from sklearn.model_selection import LeaveOneGroupOut
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import Ridge
    from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    HAS_SKLEARN = True
except Exception as e:
    HAS_SKLEARN = False
    SKLEARN_ERROR = str(e)


def rmse(y_true, y_pred):
    return float(math.sqrt(mean_squared_error(y_true, y_pred)))


def safe_spearman(x, y):
    x = pd.to_numeric(pd.Series(x), errors="coerce")
    y = pd.to_numeric(pd.Series(y), errors="coerce")
    m = x.notna() & y.notna()
    if m.sum() < 8 or x[m].nunique() < 3 or y[m].nunique() < 3:
        return np.nan
    if HAS_SCIPY:
        return float(spearmanr(x[m], y[m]).correlation)
    return float(x[m].rank().corr(y[m].rank()))


def safe_pearson(x, y):
    x = pd.to_numeric(pd.Series(x), errors="coerce")
    y = pd.to_numeric(pd.Series(y), errors="coerce")
    m = x.notna() & y.notna()
    if m.sum() < 8 or x[m].nunique() < 3 or y[m].nunique() < 3:
        return np.nan
    if HAS_SCIPY:
        return float(pearsonr(x[m], y[m])[0])
    return float(x[m].corr(y[m]))


def residualize_within_cell(df, col, control_col="rest_sequence_index", degree=2):
    residual = pd.Series(np.nan, index=df.index, dtype=float)

    for cell, g in df.groupby("cell_id", sort=False):
        y = pd.to_numeric(g[col], errors="coerce")
        x = pd.to_numeric(g[control_col], errors="coerce")
        m = y.notna() & x.notna()

        if m.sum() < 4 or x[m].nunique() < 2:
            continue

        xx = x[m].to_numpy(dtype=float)
        yy = y[m].to_numpy(dtype=float)

        cols = [np.ones_like(xx), xx]
        if degree >= 2:
            cols.append(xx ** 2)

        X = np.vstack(cols).T

        try:
            beta, *_ = np.linalg.lstsq(X, yy, rcond=None)
            residual.loc[g.index[m]] = yy - X @ beta
        except Exception:
            pass

    return residual


def add_differences(df, feature_cols):
    out = []
    for cell, g in df.sort_values(["cell_id", "rest_sequence_index"]).groupby("cell_id", sort=False):
        g = g.copy()
        for c in ["reference_soh"] + feature_cols:
            if c in g.columns:
                g[f"d_{c}"] = pd.to_numeric(g[c], errors="coerce").diff()
        out.append(g)
    return pd.concat(out, ignore_index=True)


def condition_from_cell(cell):
    try:
        n = int(str(cell).replace("RW", ""))
    except Exception:
        return "unknown"
    if 13 <= n <= 16:
        return "low_skew_room_temp"
    if 17 <= n <= 20:
        return "high_skew_room_temp"
    if 21 <= n <= 24:
        return "low_skew_40C"
    if 25 <= n <= 28:
        return "high_skew_40C"
    return "unknown"


def add_controls(df, descriptor_cols):
    out = df.copy()

    for k in range(12):
        out[f"noise_{k:02d}"] = RNG.normal(0, 1, len(out))

    for c in descriptor_cols:
        if c not in out.columns:
            continue
        sc = f"shuf_{c}"
        out[sc] = np.nan
        for cell, idx in out.groupby("cell_id").groups.items():
            vals = out.loc[idx, c].to_numpy()
            out.loc[idx, sc] = RNG.permutation(vals)

    return out


def loo_prediction(df, feature_sets):
    if not HAS_SKLEARN:
        return pd.DataFrame([{"status": "skipped", "reason": f"sklearn unavailable: {SKLEARN_ERROR}"}]), pd.DataFrame()

    work = df.dropna(subset=["reference_soh", "cell_id"]).copy()
    if len(work) < 40 or work["cell_id"].nunique() < 4:
        return pd.DataFrame([{"status": "skipped", "reason": "too few rows/cells"}]), pd.DataFrame()

    models = {
        "ridge": make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), Ridge(alpha=1.0)),
        "random_forest": make_pipeline(
            SimpleImputer(strategy="median"),
            RandomForestRegressor(n_estimators=400, min_samples_leaf=3, random_state=42, n_jobs=-1)
        ),
        "hist_gradient_boosting": HistGradientBoostingRegressor(random_state=42, max_iter=300, learning_rate=0.05),
    }

    y = pd.to_numeric(work["reference_soh"], errors="coerce").astype(float)
    groups = work["cell_id"].astype(str)
    logo = LeaveOneGroupOut()

    summary_rows = []
    fold_rows = []

    for set_name, cols in feature_sets.items():
        cols = [c for c in cols if c in work.columns]
        if not cols:
            summary_rows.append({"status": "skipped", "feature_set": set_name, "reason": "no available features"})
            continue

        X = work[cols].replace([np.inf, -np.inf], np.nan)
        X = X[[c for c in X.columns if X[c].notna().any()]]

        if X.shape[1] == 0:
            summary_rows.append({"status": "skipped", "feature_set": set_name, "reason": "no nonempty features"})
            continue

        for model_name, model in models.items():
            preds = np.full(len(work), np.nan)

            for fold_id, (train_idx, test_idx) in enumerate(logo.split(X, y, groups)):
                est = clone(model)
                est.fit(X.iloc[train_idx], y.iloc[train_idx])
                pred = est.predict(X.iloc[test_idx])
                preds[test_idx] = pred

                cell = str(groups.iloc[test_idx].iloc[0])
                fold_rows.append({
                    "feature_set": set_name,
                    "model": model_name,
                    "fold_id": int(fold_id),
                    "held_out_cell": cell,
                    "fold_mae": float(mean_absolute_error(y.iloc[test_idx], pred)),
                    "fold_rmse": rmse(y.iloc[test_idx], pred),
                    "fold_r2": float(r2_score(y.iloc[test_idx], pred)) if len(test_idx) > 1 else np.nan,
                    "n_test": int(len(test_idx)),
                })

            m = np.isfinite(preds)
            summary_rows.append({
                "status": "ok",
                "feature_set": set_name,
                "model": model_name,
                "mae_soh": float(mean_absolute_error(y[m], preds[m])),
                "rmse_soh": rmse(y[m], preds[m]),
                "r2_soh": float(r2_score(y[m], preds[m])),
                "n_rows": int(m.sum()),
                "n_cells": int(groups.nunique()),
                "n_features": int(X.shape[1]),
            })

    return pd.DataFrame(summary_rows), pd.DataFrame(fold_rows)


# -----------------------
# Load Stage 2F table
# -----------------------
df = pd.read_csv(ANALYSIS_CSV)
df["condition_group"] = df["cell_id"].map(condition_from_cell)

for c in df.columns:
    if c != "cell_id" and c != "condition_group":
        df[c] = pd.to_numeric(df[c], errors="ignore")

age_cols = ["rest_sequence_index", "rest_step_index"]

rest_cols = [
    "rest_delta_voltage_V",
    "rest_abs_delta_voltage_V",
    "rest_abs_delta_voltage_mV",
    "rest_voltage_start_V",
    "rest_voltage_end_V",
]

charge_cols = [
    "prev_charge_duration_s",
    "prev_charge_n_points",
    "prev_charge_delta_voltage_V",
    "prev_charge_abs_delta_voltage_V",
    "prev_charge_median_abs_current_A",
    "prev_charge_mean_abs_current_A",
    "prev_charge_capacity_Ah_abs_current_integral",
]

descriptor_cols = [c for c in rest_cols + charge_cols if c in df.columns]

# -----------------------
# Correlations: raw, within-cell demeaned, residualized, first difference
# -----------------------
corr_rows = []

for feat in descriptor_cols + ["rest_sequence_index"]:
    if feat not in df.columns:
        continue

    corr_rows.append({
        "method": "raw",
        "feature": feat,
        "target": "reference_soh",
        "spearman_r": safe_spearman(df[feat], df["reference_soh"]),
        "pearson_r": safe_pearson(df[feat], df["reference_soh"]),
        "n": int(df[[feat, "reference_soh"]].dropna().shape[0]),
    })

    x_dm = df[feat] - df.groupby("cell_id")[feat].transform("mean")
    y_dm = df["reference_soh"] - df.groupby("cell_id")["reference_soh"].transform("mean")
    corr_rows.append({
        "method": "within_cell_demeaned",
        "feature": feat,
        "target": "reference_soh",
        "spearman_r": safe_spearman(x_dm, y_dm),
        "pearson_r": safe_pearson(x_dm, y_dm),
        "n": int(pd.DataFrame({"x": x_dm, "y": y_dm}).dropna().shape[0]),
    })

    if feat != "rest_sequence_index":
        x_res = residualize_within_cell(df, feat)
        y_res = residualize_within_cell(df, "reference_soh")
        corr_rows.append({
            "method": "within_cell_quadratic_sequence_residual",
            "feature": feat,
            "target": "reference_soh",
            "spearman_r": safe_spearman(x_res, y_res),
            "pearson_r": safe_pearson(x_res, y_res),
            "n": int(pd.DataFrame({"x": x_res, "y": y_res}).dropna().shape[0]),
        })

diff_df = add_differences(df, descriptor_cols)
for feat in descriptor_cols:
    d_feat = f"d_{feat}"
    if d_feat not in diff_df.columns:
        continue
    corr_rows.append({
        "method": "first_difference",
        "feature": feat,
        "target": "reference_soh",
        "spearman_r": safe_spearman(diff_df[d_feat], diff_df["d_reference_soh"]),
        "pearson_r": safe_pearson(diff_df[d_feat], diff_df["d_reference_soh"]),
        "n": int(diff_df[[d_feat, "d_reference_soh"]].dropna().shape[0]),
    })

corr = pd.DataFrame(corr_rows)
corr["abs_spearman_r"] = corr["spearman_r"].abs()
corr = corr.sort_values(["method", "abs_spearman_r"], ascending=[True, False])
corr.to_csv(OUTDIR / "stage2G_v2_deconfounded_correlations.csv", index=False)

# -----------------------
# Prediction with negative controls
# -----------------------
model_df = add_controls(df, descriptor_cols)

noise_cols = [c for c in model_df.columns if c.startswith("noise_")]
shuf_cols = [c for c in model_df.columns if c.startswith("shuf_")]

feature_sets = {
    "age_baseline": age_cols,
    "rest_only_no_age": rest_cols,
    "charge_only_no_age": charge_cols,
    "rest_plus_charge_no_age": rest_cols + charge_cols,
    "age_plus_rest": age_cols + rest_cols,
    "age_plus_charge": age_cols + charge_cols,
    "age_plus_rest_plus_charge": age_cols + rest_cols + charge_cols,
    "age_plus_noise_control": age_cols + noise_cols,
    "age_plus_shuffled_descriptor_control": age_cols + shuf_cols,
}

prediction, fold_metrics = loo_prediction(model_df, feature_sets)
prediction.to_csv(OUTDIR / "stage2G_v2_leave_one_cell_out_prediction_summary.csv", index=False)
fold_metrics.to_csv(OUTDIR / "stage2G_v2_leave_one_cell_out_fold_metrics.csv", index=False)

# -----------------------
# Fold deltas vs age baseline
# -----------------------
delta_rows = []
if len(fold_metrics):
    baseline = fold_metrics[fold_metrics["feature_set"] == "age_baseline"]
    for (model, cell), bg in baseline.groupby(["model", "held_out_cell"]):
        base_mae = float(bg["fold_mae"].iloc[0])
        cand = fold_metrics[
            (fold_metrics["model"] == model) &
            (fold_metrics["held_out_cell"] == cell) &
            (fold_metrics["feature_set"] != "age_baseline")
        ]
        for _, r in cand.iterrows():
            delta_rows.append({
                "feature_set": r["feature_set"],
                "model": model,
                "held_out_cell": cell,
                "baseline_fold_mae": base_mae,
                "candidate_fold_mae": float(r["fold_mae"]),
                "delta_mae_vs_age_baseline": float(r["fold_mae"] - base_mae),
            })

delta = pd.DataFrame(delta_rows)
delta.to_csv(OUTDIR / "stage2G_v2_fold_delta_vs_age_baseline.csv", index=False)

delta_summary_rows = []
if len(delta):
    for (feature_set, model), g in delta.groupby(["feature_set", "model"]):
        vals = g["delta_mae_vs_age_baseline"].dropna()
        p_value = np.nan
        if HAS_SCIPY and len(vals) >= 6 and vals.nunique() > 1:
            try:
                p_value = float(wilcoxon(vals, alternative="less").pvalue)
            except Exception:
                p_value = np.nan
        delta_summary_rows.append({
            "feature_set": feature_set,
            "model": model,
            "n_folds": int(len(vals)),
            "mean_delta_mae_vs_age": float(vals.mean()) if len(vals) else np.nan,
            "median_delta_mae_vs_age": float(vals.median()) if len(vals) else np.nan,
            "fraction_folds_improved": float((vals < 0).mean()) if len(vals) else np.nan,
            "wilcoxon_p_less_than_age": p_value,
        })

delta_summary = pd.DataFrame(delta_summary_rows)
delta_summary.to_csv(OUTDIR / "stage2G_v2_delta_summary_vs_age_baseline.csv", index=False)

# -----------------------
# Condition group summary
# -----------------------
condition_summary = (
    df.groupby("condition_group")
    .agg(
        n_pairs=("reference_soh", "size"),
        n_cells=("cell_id", "nunique"),
        median_reference_soh=("reference_soh", "median"),
        median_rest_abs_delta_mV=("rest_abs_delta_voltage_mV", "median"),
        median_prev_charge_abs_delta_V=("prev_charge_abs_delta_voltage_V", "median"),
    )
    .reset_index()
)
condition_summary.to_csv(OUTDIR / "stage2G_v2_condition_group_summary.csv", index=False)

# -----------------------
# Interpretation flags
# -----------------------
def top_corr(method):
    q = corr[(corr["method"] == method) & (corr["feature"] != "rest_sequence_index")].dropna(subset=["abs_spearman_r"])
    if len(q) == 0:
        return np.nan, ""
    q = q.sort_values("abs_spearman_r", ascending=False)
    return float(q.iloc[0]["abs_spearman_r"]), str(q.iloc[0]["feature"])


def best_delta_contains(text):
    if len(delta_summary) == 0:
        return np.nan, np.nan, ""
    q = delta_summary[delta_summary["feature_set"].str.contains(text, regex=False)].dropna(subset=["mean_delta_mae_vs_age"])
    if len(q) == 0:
        return np.nan, np.nan, ""
    q = q.sort_values("mean_delta_mae_vs_age")
    r = q.iloc[0]
    return float(r["mean_delta_mae_vs_age"]), float(r["fraction_folds_improved"]), f'{r["feature_set"]} / {r["model"]}'


raw_abs, raw_feat = top_corr("raw")
res_abs, res_feat = top_corr("within_cell_quadratic_sequence_residual")
diff_abs, diff_feat = top_corr("first_difference")

rest_delta, rest_frac, rest_label = best_delta_contains("age_plus_rest")
noise_delta, noise_frac, noise_label = best_delta_contains("age_plus_noise_control")
shuf_delta, shuf_frac, shuf_label = best_delta_contains("age_plus_shuffled_descriptor_control")

rest_beats_noise = pd.notna(rest_delta) and pd.notna(noise_delta) and rest_delta < noise_delta
rest_beats_shuf = pd.notna(rest_delta) and pd.notna(shuf_delta) and rest_delta < shuf_delta

if pd.notna(res_abs) and res_abs >= 0.30 and rest_beats_noise and rest_beats_shuf:
    strength = "moderate_beyond_age_signal"
elif pd.notna(rest_delta) and rest_delta < -0.001 and rest_beats_noise:
    strength = "weak_to_moderate_predictive_increment"
else:
    strength = "mostly_age_protocol_alignment"

interpretation = pd.DataFrame([
    {
        "question": "Does raw descriptor correlation with SOH exist?",
        "answer": "yes" if pd.notna(raw_abs) and raw_abs >= 0.30 else "weak/no",
        "evidence": f"best raw |Spearman r|={raw_abs:.3f} for {raw_feat}" if pd.notna(raw_abs) else "not available",
    },
    {
        "question": "Does descriptor correlation survive within-cell sequence residualization?",
        "answer": "yes" if pd.notna(res_abs) and res_abs >= 0.30 else "weak/no",
        "evidence": f"best residual |Spearman r|={res_abs:.3f} for {res_feat}" if pd.notna(res_abs) else "not available",
    },
    {
        "question": "Does first-difference analysis support local descriptor-to-SOH changes?",
        "answer": "yes" if pd.notna(diff_abs) and diff_abs >= 0.30 else "weak/no",
        "evidence": f"best first-difference |Spearman r|={diff_abs:.3f} for {diff_feat}" if pd.notna(diff_abs) else "not available",
    },
    {
        "question": "Does age+rest improve leave-one-cell-out prediction over age baseline?",
        "answer": "yes" if pd.notna(rest_delta) and rest_delta < -0.001 else "no/unclear",
        "evidence": f"best delta={rest_delta:.5f}; improved folds={rest_frac:.2f}; {rest_label}" if pd.notna(rest_delta) else "not available",
    },
    {
        "question": "Does age+rest beat noise and shuffled-descriptor controls?",
        "answer": "yes" if rest_beats_noise and rest_beats_shuf else "no/unclear",
        "evidence": f"rest delta={rest_delta:.5f}; noise delta={noise_delta:.5f}; shuffled delta={shuf_delta:.5f}",
    },
    {
        "question": "Recommended manuscript strength",
        "answer": strength,
        "evidence": "Use this as the Stage 2G public reproducibility strength label.",
    },
])
interpretation.to_csv(OUTDIR / "stage2G_v2_interpretation_flags.csv", index=False)

# -----------------------
# Figures
# -----------------------
if HAS_MPL:
    for method, fname, title in [
        ("raw", "fig_stage2G_v2_raw_correlations.png", "Raw descriptor correlations vs SOH"),
        ("within_cell_quadratic_sequence_residual", "fig_stage2G_v2_sequence_residual_correlations.png", "Sequence-residual descriptor correlations vs SOH"),
        ("first_difference", "fig_stage2G_v2_first_difference_correlations.png", "First-difference correlations vs ΔSOH"),
    ]:
        q = corr[(corr["method"] == method) & (corr["feature"] != "rest_sequence_index")]
        q = q.dropna(subset=["abs_spearman_r"]).sort_values("abs_spearman_r", ascending=False).head(15)
        if len(q):
            plt.figure(figsize=(10, 5))
            plt.bar(q["feature"], q["abs_spearman_r"])
            plt.xticks(rotation=45, ha="right")
            plt.ylabel("|Spearman r|")
            plt.title(title)
            plt.tight_layout()
            plt.savefig(FIGDIR / fname, dpi=200)
            plt.close()

    if len(delta_summary):
        q = delta_summary.dropna(subset=["mean_delta_mae_vs_age"]).copy()
        q["label"] = q["feature_set"] + " / " + q["model"]
        q = q.sort_values("mean_delta_mae_vs_age")
        plt.figure(figsize=(12, 5))
        plt.bar(q["label"], q["mean_delta_mae_vs_age"])
        plt.axhline(0, linewidth=1)
        plt.xticks(rotation=45, ha="right")
        plt.ylabel("Mean fold ΔMAE vs age baseline")
        plt.title("Stage 2G v2 prediction delta vs age baseline")
        plt.tight_layout()
        plt.savefig(FIGDIR / "fig_stage2G_v2_prediction_delta_vs_age.png", dpi=200)
        plt.close()

    plt.figure(figsize=(8, 5))
    for cond, g in df.groupby("condition_group"):
        plt.scatter(g["rest_sequence_index"], g["reference_soh"], s=18, alpha=0.75, label=cond)
    plt.xlabel("Reference/rest sequence index")
    plt.ylabel("Reference SOH proxy")
    plt.title("SOH trajectory by NASA RW condition group")
    plt.legend(fontsize=7)
    plt.tight_layout()
    plt.savefig(FIGDIR / "fig_stage2G_v2_soh_by_condition_group.png", dpi=200)
    plt.close()

# -----------------------
# Summary + report
# -----------------------
summary = {
    "outdir": str(OUTDIR),
    "stage2F_dir": str(ANALYSIS_CSV.parent),
    "analysis_csv": str(ANALYSIS_CSV),
    "n_rows": int(len(df)),
    "n_cells": int(df["cell_id"].nunique()),
    "best_raw_abs_spearman": None if pd.isna(raw_abs) else raw_abs,
    "best_raw_feature": raw_feat,
    "best_sequence_residual_abs_spearman": None if pd.isna(res_abs) else res_abs,
    "best_sequence_residual_feature": res_feat,
    "best_first_difference_abs_spearman": None if pd.isna(diff_abs) else diff_abs,
    "best_first_difference_feature": diff_feat,
    "best_age_plus_rest_delta_mae": None if pd.isna(rest_delta) else rest_delta,
    "best_age_plus_rest_label": rest_label,
    "best_noise_control_delta_mae": None if pd.isna(noise_delta) else noise_delta,
    "best_shuffled_control_delta_mae": None if pd.isna(shuf_delta) else shuf_delta,
    "manuscript_strength": strength,
    "has_scipy": HAS_SCIPY,
    "has_sklearn": HAS_SKLEARN,
    "has_matplotlib": HAS_MPL,
    "outputs": {
        "correlations": str(OUTDIR / "stage2G_v2_deconfounded_correlations.csv"),
        "prediction_summary": str(OUTDIR / "stage2G_v2_leave_one_cell_out_prediction_summary.csv"),
        "fold_metrics": str(OUTDIR / "stage2G_v2_leave_one_cell_out_fold_metrics.csv"),
        "delta_summary": str(OUTDIR / "stage2G_v2_delta_summary_vs_age_baseline.csv"),
        "condition_summary": str(OUTDIR / "stage2G_v2_condition_group_summary.csv"),
        "interpretation_flags": str(OUTDIR / "stage2G_v2_interpretation_flags.csv"),
        "figures": str(FIGDIR),
    },
}
with open(OUTDIR / "stage2G_v2_summary.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

strength_text = {
    "moderate_beyond_age_signal": "The descriptor signal survives enough deconfounding to support a moderate beyond-age metadata/prognostic claim.",
    "weak_to_moderate_predictive_increment": "The result supports a weak-to-moderate predictive increment; emphasize metadata preservation and prognostic alignment.",
    "mostly_age_protocol_alignment": "The result mainly supports protocol/sequence alignment; use it as a data-governance and metadata-preservation argument."
}.get(strength, "Interpret cautiously.")

report = []
report.append("# Stage 2G v2 Deconfounded Rest-to-SOH Robustness Report\n")
report.append(f"Generated: {datetime.now().isoformat(timespec='seconds')}\n")
report.append("\n## Summary\n")
report.append(json.dumps(summary, indent=2))
report.append("\n\n## Interpretation flags\n")
report.append(interpretation.to_markdown(index=False))
report.append("\n\n## Top sequence-residual correlations\n")
q = corr[corr["method"] == "within_cell_quadratic_sequence_residual"].dropna(subset=["abs_spearman_r"]).head(20)
report.append(q.to_markdown(index=False) if len(q) else "No residualized correlations.")
report.append("\n\n## Prediction delta summary vs age baseline\n")
report.append(delta_summary.to_markdown(index=False) if len(delta_summary) else "No prediction deltas.")
report.append("\n\n## Public-validation-safe interpretation\n")
report.append(strength_text)
report.append("\n\n## Suggested manuscript sentence\n")
report.append("> Deconfounding analyses show that explicit rest/reference step metadata is necessary to align randomized-use intervals with reference-capacity benchmarks. The strongest signal is expected to track aging/protocol sequence, while rest and pre-reference descriptors are interpreted as structured operational-state information rather than direct evidence for a specific electrochemical degradation mechanism.")

(OUTDIR / "stage2G_v2_deconfounded_rest_soh_report.md").write_text("\n".join(report), encoding="utf-8")

print("\n=== STAGE 2G v2 SUMMARY ===")
print(json.dumps(summary, indent=2))

print("\n=== INTERPRETATION FLAGS ===")
print(interpretation.to_string(index=False))

print("\n=== TOP SEQUENCE-RESIDUAL CORRELATIONS ===")
print(q.to_string(index=False) if len(q) else "No residualized correlations.")

print("\n=== PREDICTION SUMMARY ===")
print(prediction.to_string(index=False) if len(prediction) else "No prediction summary.")

print("\n=== DELTA SUMMARY VS AGE BASELINE ===")
print(delta_summary.to_string(index=False) if len(delta_summary) else "No delta summary.")

print("\nDONE")
print(OUTDIR)
