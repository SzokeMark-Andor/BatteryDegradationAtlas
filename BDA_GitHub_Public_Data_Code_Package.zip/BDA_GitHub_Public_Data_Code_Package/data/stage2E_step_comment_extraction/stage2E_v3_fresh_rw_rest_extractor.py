from pathlib import Path
import os
import re
import json
import math
import time
import warnings
from datetime import datetime
from collections import Counter, defaultdict

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

ROOT = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas")
OUTDIR = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304")
OUTDIR.mkdir(parents=True, exist_ok=True)
FIGDIR = OUTDIR / "figures"
FIGDIR.mkdir(exist_ok=True)

MAX_MAT_FILES = int(os.environ.get("BDA_STAGE2E_V3_MAX_MAT", "16"))
RANDOM_ROOT = ROOT / "data" / "raw" / "nasa_pcoe" / "extracted" / "random"

try:
    import scipy.io
    HAS_SCIPY = True
except Exception as e:
    HAS_SCIPY = False
    SCIPY_ERROR = str(e)

try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except Exception:
    HAS_MPL = False


def area_trapezoid(y, x):
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    m = np.isfinite(y) & np.isfinite(x)
    y = y[m]
    x = x[m]
    if len(y) < 2:
        return np.nan
    order = np.argsort(x)
    y = y[order]
    x = x[order]
    if hasattr(np, "trapezoid"):
        return float(np.trapezoid(y, x))
    return float(np.sum((y[:-1] + y[1:]) * np.diff(x) / 2.0))


def to_native(obj):
    if isinstance(obj, dict):
        return {k: to_native(v) for k, v in obj.items() if not str(k).startswith("__")}
    if hasattr(obj, "_fieldnames"):
        return {k: to_native(getattr(obj, k)) for k in obj._fieldnames}
    if isinstance(obj, np.ndarray):
        if obj.dtype == object:
            return [to_native(x) for x in obj.ravel()]
        return obj
    return obj


def load_mat(path):
    if not HAS_SCIPY:
        raise RuntimeError(f"scipy unavailable: {SCIPY_ERROR}")
    try:
        return to_native(scipy.io.loadmat(path, simplify_cells=True))
    except TypeError:
        return to_native(scipy.io.loadmat(path, squeeze_me=True, struct_as_record=False))


def as_step_list(x):
    if x is None:
        return []
    if isinstance(x, list):
        return x
    if isinstance(x, tuple):
        return list(x)
    if isinstance(x, np.ndarray):
        if x.dtype == object:
            return [to_native(v) for v in x.ravel()]
        return [x]
    if isinstance(x, dict):
        return [x]
    return [x]


def field(d, names):
    if not isinstance(d, dict):
        return None
    lower = {str(k).lower(): k for k in d.keys()}
    for name in names:
        if name in d:
            return d[name]
        key = lower.get(str(name).lower())
        if key is not None:
            return d[key]
    return None


def stringify(x):
    if x is None:
        return ""
    if isinstance(x, bytes):
        return x.decode(errors="ignore")
    if isinstance(x, np.ndarray):
        if x.size == 1:
            return stringify(x.item())
        return " ".join(stringify(v) for v in x.ravel()[:20])
    return str(x)


def arr_float(x):
    if x is None:
        return np.array([], dtype=float)
    try:
        return np.asarray(x, dtype=float).ravel()
    except Exception:
        return np.array([], dtype=float)


def find_rw_files():
    candidates = []
    if not RANDOM_ROOT.exists():
        return candidates

    for dirpath, dirnames, filenames in os.walk(RANDOM_ROOT, topdown=True, onerror=lambda e: None):
        pdir = Path(dirpath)
        low_dir = str(pdir).lower()

        if "data\\matlab" not in low_dir and "data/matlab" not in low_dir:
            continue

        for fname in filenames:
            low = fname.lower()
            if re.match(r"^rw\d+(\.mat)?$", low):
                candidates.append(pdir / fname)

    return sorted(candidates)


def step_arrays(st):
    t = arr_float(field(st, ["relativeTime", "relative_time", "time", "Time", "t"]))
    v = arr_float(field(st, ["voltage", "Voltage", "voltage_V", "Voltage_measured"]))
    i = arr_float(field(st, ["current", "Current", "current_A", "Current_measured"]))

    n = min(len(t), len(v), len(i))
    if n <= 0:
        return np.array([]), np.array([]), np.array([])

    return t[:n], v[:n], i[:n]


def descriptor_from_arrays(t, v, i):
    out = {
        "n_points": int(min(len(t), len(v), len(i))),
        "duration_s": np.nan,
        "voltage_start_V": np.nan,
        "voltage_end_V": np.nan,
        "delta_voltage_V": np.nan,
        "abs_delta_voltage_V": np.nan,
        "voltage_min_V": np.nan,
        "voltage_max_V": np.nan,
        "median_abs_current_A": np.nan,
        "mean_abs_current_A": np.nan,
        "capacity_Ah_abs_current_integral": np.nan,
        "slope_early_V_per_s": np.nan,
        "slope_late_V_per_s": np.nan,
    }

    n = out["n_points"]
    if n <= 0:
        return out

    t = np.asarray(t[:n], dtype=float)
    v = np.asarray(v[:n], dtype=float)
    i = np.asarray(i[:n], dtype=float)
    m = np.isfinite(t) & np.isfinite(v) & np.isfinite(i)

    t = t[m]
    v = v[m]
    i = i[m]

    if len(t) <= 0:
        return out

    order = np.argsort(t)
    t = t[order]
    v = v[order]
    i = i[order]

    out["n_points"] = int(len(t))
    out["duration_s"] = float(np.nanmax(t) - np.nanmin(t)) if len(t) > 1 else 0.0
    out["voltage_start_V"] = float(v[0])
    out["voltage_end_V"] = float(v[-1])
    out["delta_voltage_V"] = float(v[-1] - v[0])
    out["abs_delta_voltage_V"] = float(abs(v[-1] - v[0]))
    out["voltage_min_V"] = float(np.nanmin(v))
    out["voltage_max_V"] = float(np.nanmax(v))
    out["median_abs_current_A"] = float(np.nanmedian(np.abs(i)))
    out["mean_abs_current_A"] = float(np.nanmean(np.abs(i)))
    out["capacity_Ah_abs_current_integral"] = float(area_trapezoid(np.abs(i), t) / 3600.0)

    try:
        if len(t) >= 10 and out["duration_s"] > 0:
            tr = t - t.min()
            k = max(3, min(20, len(tr) // 5))
            out["slope_early_V_per_s"] = float(np.polyfit(tr[:k], v[:k], 1)[0])
            out["slope_late_V_per_s"] = float(np.polyfit(tr[-k:], v[-k:], 1)[0])
    except Exception:
        pass

    return out


mat_files = find_rw_files()[:MAX_MAT_FILES]

file_rows = []
target_step_rows = []
comment_counter = Counter()
comment_by_cell = defaultdict(Counter)
example_curves = []

for file_idx, mat_path in enumerate(mat_files, start=1):
    cell_id = mat_path.stem if mat_path.suffix else mat_path.name
    print(f"[{file_idx}/{len(mat_files)}] Loading {cell_id}: {mat_path}", flush=True)

    file_row = {
        "cell_id": cell_id,
        "file": str(mat_path.relative_to(ROOT)),
        "size_bytes": mat_path.stat().st_size,
        "load_status": "started",
        "n_steps": 0,
        "n_unique_comments": 0,
        "n_rest_prior_reference_discharge": 0,
        "n_charge_after_random_walk_discharge": 0,
        "n_reference_discharge": 0,
        "n_target_rows": 0,
        "error": ""
    }

    try:
        mat = load_mat(mat_path)

        data = None
        if isinstance(mat, dict):
            data = mat.get("data", None)
            if data is None:
                data = mat.get("Data", None)

        if data is None:
            raise KeyError("MAT file has no data/Data variable.")

        data = to_native(data)
        steps = field(data, ["step", "steps"])
        steps = as_step_list(steps)

        file_row["load_status"] = "ok"
        file_row["n_steps"] = int(len(steps))

        local_comments = Counter()

        prev_comment = ""
        prev_desc = {}

        for step_index, st in enumerate(steps):
            st = to_native(st)
            if not isinstance(st, dict):
                continue

            comment = stringify(field(st, ["comment", "label", "type", "operation"])).strip()
            comment_l = comment.lower()

            local_comments[comment] += 1
            comment_counter[comment] += 1
            comment_by_cell[cell_id][comment] += 1

            is_rest_prior_ref = "rest prior reference discharge" in comment_l
            is_charge_after_rw = "charge (after random walk discharge)" in comment_l
            is_reference_discharge = ("reference discharge" in comment_l) and ("rest" not in comment_l)

            if is_rest_prior_ref:
                file_row["n_rest_prior_reference_discharge"] += 1
            if is_charge_after_rw:
                file_row["n_charge_after_random_walk_discharge"] += 1
            if is_reference_discharge:
                file_row["n_reference_discharge"] += 1

            # Store only scientifically relevant steps to avoid giant CSVs.
            if is_rest_prior_ref or is_charge_after_rw or is_reference_discharge:
                t, v, i = step_arrays(st)
                desc = descriptor_from_arrays(t, v, i)

                row = {
                    "cell_id": cell_id,
                    "file": str(mat_path.relative_to(ROOT)),
                    "step_index": int(step_index),
                    "comment": comment,
                    "prev_comment": prev_comment,
                    "is_rest_prior_reference_discharge": bool(is_rest_prior_ref),
                    "is_charge_after_random_walk_discharge": bool(is_charge_after_rw),
                    "is_reference_discharge": bool(is_reference_discharge),
                    "prev_n_points": prev_desc.get("n_points", np.nan),
                    "prev_duration_s": prev_desc.get("duration_s", np.nan),
                    "prev_median_abs_current_A": prev_desc.get("median_abs_current_A", np.nan),
                    **desc
                }

                # Conservative relaxation-candidate flag: explicit rest label + measurable voltage/time.
                row["is_explicit_rest_descriptor_candidate"] = bool(
                    is_rest_prior_ref and
                    row["n_points"] >= 2 and
                    pd.notna(row["duration_s"]) and
                    row["duration_s"] >= 1 and
                    pd.notna(row["abs_delta_voltage_V"])
                )

                target_step_rows.append(row)
                file_row["n_target_rows"] += 1

                if row["is_explicit_rest_descriptor_candidate"] and len(example_curves) < 20 and len(t) > 1:
                    n = min(len(t), len(v), len(i))
                    tmp = pd.DataFrame({
                        "cell_id": cell_id,
                        "step_index": step_index,
                        "comment": comment,
                        "t_rel_s": t[:n] - np.nanmin(t[:n]),
                        "voltage_V": v[:n],
                        "current_A": i[:n]
                    })
                    example_curves.append(tmp)

                prev_desc = desc

            prev_comment = comment

        file_row["n_unique_comments"] = int(len(local_comments))

    except Exception as e:
        file_row["load_status"] = "error"
        file_row["error"] = str(e)[:1000]

    file_rows.append(file_row)

    # Incremental writes after every file.
    pd.DataFrame(file_rows).to_csv(OUTDIR / "stage2E_v3_mat_file_progress.csv", index=False)
    pd.DataFrame(target_step_rows).to_csv(OUTDIR / "stage2E_v3_target_step_descriptors_progress.csv", index=False)

file_df = pd.DataFrame(file_rows)
target_df = pd.DataFrame(target_step_rows)

comment_df = pd.DataFrame(
    [{"comment": k, "count": v} for k, v in comment_counter.items()]
).sort_values("count", ascending=False) if len(comment_counter) else pd.DataFrame(columns=["comment", "count"])

cell_comment_rows = []
for cell, counter in comment_by_cell.items():
    for comment, count in counter.items():
        cell_comment_rows.append({
            "cell_id": cell,
            "comment": comment,
            "count": count
        })
cell_comment_df = pd.DataFrame(cell_comment_rows)

file_df.to_csv(OUTDIR / "stage2E_v3_mat_file_inventory.csv", index=False)
target_df.to_csv(OUTDIR / "stage2E_v3_target_step_descriptors.csv", index=False)
comment_df.to_csv(OUTDIR / "stage2E_v3_comment_counts.csv", index=False)
cell_comment_df.to_csv(OUTDIR / "stage2E_v3_comment_counts_by_cell.csv", index=False)

# Split outputs for direct inspection.
if len(target_df):
    target_df[target_df["is_rest_prior_reference_discharge"] == True].to_csv(
        OUTDIR / "stage2E_v3_rest_prior_reference_descriptors.csv",
        index=False
    )
    target_df[target_df["is_charge_after_random_walk_discharge"] == True].to_csv(
        OUTDIR / "stage2E_v3_charge_after_random_walk_descriptors.csv",
        index=False
    )
    target_df[target_df["is_reference_discharge"] == True].to_csv(
        OUTDIR / "stage2E_v3_reference_discharge_descriptors.csv",
        index=False
    )

if HAS_MPL:
    if len(comment_df):
        tmp = comment_df.head(20).copy()
        plt.figure(figsize=(10, 6))
        plt.barh(tmp["comment"].astype(str), tmp["count"])
        plt.xlabel("Step count")
        plt.title("NASA RW step comments")
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.savefig(FIGDIR / "fig_stage2E_v3_comment_counts.png", dpi=200)
        plt.close()

    if len(target_df) and "abs_delta_voltage_V" in target_df.columns:
        rest = target_df[target_df["is_rest_prior_reference_discharge"] == True].copy()
        if len(rest):
            plt.figure(figsize=(9, 5))
            plt.scatter(rest["step_index"], rest["abs_delta_voltage_V"], s=14)
            plt.xlabel("Step index")
            plt.ylabel("|ΔV| during explicit rest step (V)")
            plt.title("Explicit rest-prior-reference-discharge voltage change")
            plt.tight_layout()
            plt.savefig(FIGDIR / "fig_stage2E_v3_rest_delta_voltage.png", dpi=200)
            plt.close()

    if example_curves:
        curves = pd.concat(example_curves, ignore_index=True)
        plt.figure(figsize=(10, 6))
        for (cell, step), g in curves.groupby(["cell_id", "step_index"]):
            g = g.sort_values("t_rel_s")
            plt.plot(g["t_rel_s"], g["voltage_V"], alpha=0.75, label=f"{cell} step {step}")
        plt.xlabel("Relative time in explicit rest step (s)")
        plt.ylabel("Voltage (V)")
        plt.title("Example explicit rest-prior-reference-discharge voltage curves")
        plt.legend(fontsize=7, ncol=2)
        plt.tight_layout()
        plt.savefig(FIGDIR / "fig_stage2E_v3_example_rest_curves.png", dpi=200)
        plt.close()

summary = {
    "outdir": str(OUTDIR),
    "random_root": str(RANDOM_ROOT),
    "n_mat_files_found": len(find_rw_files()),
    "n_mat_files_processed": int(len(file_df)),
    "n_loaded_ok": int((file_df["load_status"] == "ok").sum()) if len(file_df) else 0,
    "n_total_steps_reported": int(file_df["n_steps"].sum()) if len(file_df) and "n_steps" in file_df.columns else 0,
    "n_unique_comments": int(comment_df["comment"].nunique()) if len(comment_df) else 0,
    "n_target_step_rows": int(len(target_df)),
    "n_rest_prior_reference_rows": int((target_df["is_rest_prior_reference_discharge"] == True).sum()) if len(target_df) else 0,
    "n_charge_after_random_walk_rows": int((target_df["is_charge_after_random_walk_discharge"] == True).sum()) if len(target_df) else 0,
    "n_reference_discharge_rows": int((target_df["is_reference_discharge"] == True).sum()) if len(target_df) else 0,
    "n_explicit_rest_descriptor_candidates": int((target_df["is_explicit_rest_descriptor_candidate"] == True).sum()) if len(target_df) else 0,
    "has_scipy": HAS_SCIPY,
    "has_matplotlib": HAS_MPL,
    "outputs": {
        "mat_file_inventory": str(OUTDIR / "stage2E_v3_mat_file_inventory.csv"),
        "target_step_descriptors": str(OUTDIR / "stage2E_v3_target_step_descriptors.csv"),
        "rest_prior_reference_descriptors": str(OUTDIR / "stage2E_v3_rest_prior_reference_descriptors.csv"),
        "comment_counts": str(OUTDIR / "stage2E_v3_comment_counts.csv"),
        "figures": str(FIGDIR)
    }
}

with open(OUTDIR / "stage2E_v3_summary.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

report = []
report.append("# Stage 2E v3 NASA Randomized Explicit Rest-Step Report\n")
report.append(f"Generated: {datetime.now().isoformat(timespec='seconds')}\n")
report.append("\n## Summary\n")
report.append(json.dumps(summary, indent=2))
report.append("\n\n## Top step comments\n")
report.append(comment_df.head(30).to_markdown(index=False) if len(comment_df) else "No comments extracted.")
report.append("\n\n## File processing summary\n")
report.append(file_df.to_markdown(index=False) if len(file_df) else "No files processed.")
report.append("\n\n## Target descriptor preview\n")
preview_cols = [
    "cell_id", "step_index", "comment", "prev_comment",
    "n_points", "duration_s", "median_abs_current_A",
    "abs_delta_voltage_V", "slope_early_V_per_s", "slope_late_V_per_s",
    "is_explicit_rest_descriptor_candidate"
]
preview_cols = [c for c in preview_cols if c in target_df.columns]
report.append(target_df[preview_cols].head(40).to_markdown(index=False) if len(target_df) else "No target steps extracted.")
report.append("\n\n## Interpretation guardrail\n")
report.append("These outputs establish whether explicit rest-prior-reference-discharge steps contain measurable voltage-time-current descriptors. They should be interpreted as relaxation-state or polarization-recovery descriptors only, not as direct evidence of SEI growth, loss of active material, or a named overpotential mechanism without additional physical validation.")

(OUTDIR / "stage2E_v3_report.md").write_text("\n".join(report), encoding="utf-8")

print("\n=== STAGE 2E v3 SUMMARY ===")
print(json.dumps(summary, indent=2))

print("\n=== TOP COMMENTS ===")
print(comment_df.head(30).to_string(index=False) if len(comment_df) else "No comments extracted.")

print("\n=== FILE SUMMARY ===")
print(file_df.to_string(index=False) if len(file_df) else "No files processed.")

print("\n=== TARGET DESCRIPTOR PREVIEW ===")
if len(target_df):
    cols = [
        "cell_id", "step_index", "comment", "prev_comment",
        "n_points", "duration_s", "median_abs_current_A",
        "abs_delta_voltage_V", "is_explicit_rest_descriptor_candidate"
    ]
    cols = [c for c in cols if c in target_df.columns]
    print(target_df[cols].head(50).to_string(index=False))
else:
    print("No target descriptors extracted.")

print("\nDONE")
print(OUTDIR)
