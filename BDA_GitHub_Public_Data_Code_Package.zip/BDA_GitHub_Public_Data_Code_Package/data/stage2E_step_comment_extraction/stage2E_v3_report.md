# Stage 2E v3 NASA Randomized Explicit Rest-Step Report

Generated: 2026-05-05T14:33:39


## Summary

{
  "outdir": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304",
  "random_root": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\data\\raw\\nasa_pcoe\\extracted\\random",
  "n_mat_files_found": 16,
  "n_mat_files_processed": 16,
  "n_loaded_ok": 16,
  "n_total_steps_reported": 563959,
  "n_unique_comments": 14,
  "n_target_step_rows": 14721,
  "n_rest_prior_reference_rows": 298,
  "n_charge_after_random_walk_rows": 14126,
  "n_reference_discharge_rows": 297,
  "n_explicit_rest_descriptor_candidates": 298,
  "has_scipy": true,
  "has_matplotlib": true,
  "outputs": {
    "mat_file_inventory": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304\\stage2E_v3_mat_file_inventory.csv",
    "target_step_descriptors": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304\\stage2E_v3_target_step_descriptors.csv",
    "rest_prior_reference_descriptors": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304\\stage2E_v3_rest_prior_reference_descriptors.csv",
    "comment_counts": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304\\stage2E_v3_comment_counts.csv",
    "figures": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2E_v3_fresh_rw_rest_20260505_143304\\figures"
  }
}


## Top step comments

| comment                              |   count |
|:-------------------------------------|--------:|
| discharge (random walk)              |  271408 |
| rest (random walk)                   |  256375 |
| charge (after random walk discharge) |   14126 |
| rest post random walk discharge      |   13597 |
| pulsed load (discharge)              |    3061 |
| pulsed load (rest)                   |    3022 |
| rest prior reference discharge       |     298 |
| reference charge                     |     297 |
| rest post reference discharge        |     297 |
| reference discharge                  |     297 |
| rest post reference charge           |     297 |
| reference power discharge            |     297 |
| rest post reference power discharge  |     296 |
| rest post pulsed load                |     291 |


## File processing summary

| cell_id   | file                                                                                                                                                                                     |   size_bytes | load_status   |   n_steps |   n_unique_comments |   n_rest_prior_reference_discharge |   n_charge_after_random_walk_discharge |   n_reference_discharge |   n_target_rows | error   |
|:----------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------:|:--------------|----------:|--------------------:|-----------------------------------:|---------------------------------------:|------------------------:|----------------:|:--------|
| RW25      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\4. RW_Skewed_High_40C_DataSet_2Post_unzipped\RW_Skewed_High_40C_DataSet_2Post\data\Matlab\RW25.mat             |     11188968 | ok            |     20508 |                  14 |                                 13 |                                    613 |                      13 |             639 |         |
| RW26      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\4. RW_Skewed_High_40C_DataSet_2Post_unzipped\RW_Skewed_High_40C_DataSet_2Post\data\Matlab\RW26.mat             |      9750077 | ok            |     16666 |                  14 |                                 14 |                                    664 |                      14 |             692 |         |
| RW27      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\4. RW_Skewed_High_40C_DataSet_2Post_unzipped\RW_Skewed_High_40C_DataSet_2Post\data\Matlab\RW27.mat             |     12156834 | ok            |     23659 |                  14 |                                 12 |                                    605 |                      12 |             629 |         |
| RW28      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\4. RW_Skewed_High_40C_DataSet_2Post_unzipped\RW_Skewed_High_40C_DataSet_2Post\data\Matlab\RW28.mat             |     11154359 | ok            |     21121 |                  14 |                                 12 |                                    611 |                      12 |             635 |         |
| RW17      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\5. RW_Skewed_High_Room_Temp_DataSet_2Post_unzipped\RW_Skewed_High_Room_Temp_DataSet_2Post\data\Matlab\RW17.mat |     16860138 | ok            |     30912 |                  14 |                                 29 |                                   1342 |                      29 |            1400 |         |
| RW18      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\5. RW_Skewed_High_Room_Temp_DataSet_2Post_unzipped\RW_Skewed_High_Room_Temp_DataSet_2Post\data\Matlab\RW18.mat |     16902160 | ok            |     31877 |                  14 |                                 29 |                                   1284 |                      28 |            1341 |         |
| RW19      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\5. RW_Skewed_High_Room_Temp_DataSet_2Post_unzipped\RW_Skewed_High_Room_Temp_DataSet_2Post\data\Matlab\RW19.mat |     17975431 | ok            |     33877 |                  14 |                                 27 |                                   1307 |                      27 |            1361 |         |
| RW20      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\5. RW_Skewed_High_Room_Temp_DataSet_2Post_unzipped\RW_Skewed_High_Room_Temp_DataSet_2Post\data\Matlab\RW20.mat |     16364907 | ok            |     29018 |                  14 |                                 29 |                                   1384 |                      29 |            1442 |         |
| RW21      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\6. RW_Skewed_Low_40C_DataSet_2Post_unzipped\RW_Skewed_Low_40C_DataSet_2Post\data\Matlab\RW21.mat               |     18009281 | ok            |     42700 |                  14 |                                 11 |                                    523 |                      11 |             545 |         |
| RW22      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\6. RW_Skewed_Low_40C_DataSet_2Post_unzipped\RW_Skewed_Low_40C_DataSet_2Post\data\Matlab\RW22.mat               |     16787921 | ok            |     39540 |                  14 |                                 10 |                                    505 |                      10 |             525 |         |
| RW23      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\6. RW_Skewed_Low_40C_DataSet_2Post_unzipped\RW_Skewed_Low_40C_DataSet_2Post\data\Matlab\RW23.mat               |     17542587 | ok            |     41694 |                  14 |                                 11 |                                    511 |                      11 |             533 |         |
| RW24      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\6. RW_Skewed_Low_40C_DataSet_2Post_unzipped\RW_Skewed_Low_40C_DataSet_2Post\data\Matlab\RW24.mat               |     17085027 | ok            |     40384 |                  14 |                                 11 |                                    531 |                      11 |             553 |         |
| RW13      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\7. RW_Skewed_Low_Room_Temp_DataSet_2Post_unzipped\RW_Skewed_Low_Room_Temp_DataSet_2Post\data\Matlab\RW13.mat   |     24644821 | ok            |     56049 |                  14 |                                 23 |                                   1106 |                      23 |            1152 |         |
| RW14      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\7. RW_Skewed_Low_Room_Temp_DataSet_2Post_unzipped\RW_Skewed_Low_Room_Temp_DataSet_2Post\data\Matlab\RW14.mat   |     20694398 | ok            |     45868 |                  14 |                                 24 |                                   1119 |                      24 |            1167 |         |
| RW15      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\7. RW_Skewed_Low_Room_Temp_DataSet_2Post_unzipped\RW_Skewed_Low_Room_Temp_DataSet_2Post\data\Matlab\RW15.mat   |     21659643 | ok            |     47720 |                  14 |                                 24 |                                   1124 |                      24 |            1172 |         |
| RW16      | data\raw\nasa_pcoe\extracted\random\11. Randomized Battery Usage Data Set\7. RW_Skewed_Low_Room_Temp_DataSet_2Post_unzipped\RW_Skewed_Low_Room_Temp_DataSet_2Post\data\Matlab\RW16.mat   |     18624735 | ok            |     42366 |                  14 |                                 19 |                                    897 |                      19 |             935 |         |


## Target descriptor preview

| cell_id   |   step_index | comment                              | prev_comment                         |   n_points |   duration_s |   median_abs_current_A |   abs_delta_voltage_V |   slope_early_V_per_s |   slope_late_V_per_s | is_explicit_rest_descriptor_candidate   |
|:----------|-------------:|:-------------------------------------|:-------------------------------------|-----------:|-------------:|-----------------------:|----------------------:|----------------------:|---------------------:|:----------------------------------------|
| RW25      |            0 | charge (after random walk discharge) |                                      |        177 |     10528.1  |                 0.157  |                 0.146 |           0.000104436 |         -5.92612e-19 | False                                   |
| RW25      |            1 | rest prior reference discharge       | charge (after random walk discharge) |          6 |       299.99 |                 0      |                 0.001 |         nan           |        nan           | True                                    |
| RW25      |            2 | reference discharge                  | rest prior reference discharge       |        257 |      7678.18 |                 1      |                 0.874 |          -0.000164286 |         -0.000462078 | False                                   |
| RW25      |           36 | charge (after random walk discharge) | rest post random walk discharge      |        192 |     11424.5  |                 0.218  |                 0.492 |           0.000211266 |          3.26918e-19 | False                                   |
| RW25      |           58 | charge (after random walk discharge) | rest post random walk discharge      |        131 |      7747.91 |                 0.104  |                 0.009 |           2.14286e-06 |          4.7204e-19  | False                                   |
| RW25      |          100 | charge (after random walk discharge) | rest post random walk discharge      |        154 |      9176.38 |                 0.1345 |                 0.153 |           0.000113897 |         -7.25616e-19 | False                                   |
| RW25      |          124 | charge (after random walk discharge) | rest post random walk discharge      |        132 |      7818.3  |                 0.1015 |                 0.025 |           5.95238e-06 |         -2.28869e-19 | False                                   |
| RW25      |          166 | charge (after random walk discharge) | rest post random walk discharge      |        150 |      8903.06 |                 0.1295 |                 0.147 |           0.000101278 |         -5.54616e-19 | False                                   |
| RW25      |          212 | charge (after random walk discharge) | rest post random walk discharge      |        149 |      8856.5  |                 0.146  |                 0.166 |           0.000131391 |          2.45311e-19 | False                                   |
| RW25      |          236 | charge (after random walk discharge) | rest post random walk discharge      |        129 |      7640.76 |                 0.114  |                 0.045 |           1.07143e-05 |         -8.35473e-20 | False                                   |
| RW25      |          282 | charge (after random walk discharge) | rest post random walk discharge      |        147 |      8733.83 |                 0.146  |                 0.166 |           0.00013193  |          4.14451e-19 | False                                   |
| RW25      |          328 | charge (after random walk discharge) | rest post random walk discharge      |        150 |      8928.46 |                 0.1625 |                 0.181 |           0.000148571 |         -2.48629e-20 | False                                   |
| RW25      |          352 | charge (after random walk discharge) | rest post random walk discharge      |        126 |      7461.78 |                 0.122  |                 0.052 |           1.2381e-05  |          3.15947e-20 | False                                   |
| RW25      |          396 | charge (after random walk discharge) | rest post random walk discharge      |        152 |      9007.32 |                 0.16   |                 0.184 |           0.000149699 |         -3.75684e-19 | False                                   |
| RW25      |          436 | charge (after random walk discharge) | rest post random walk discharge      |        112 |      6627.94 |                 0.2645 |                 0.148 |           0.000106992 |         -9.15077e-07 | False                                   |
| RW25      |          474 | charge (after random walk discharge) | rest post random walk discharge      |        142 |      8449.8  |                 0.136  |                 0.145 |           9.33333e-05 |         -6.76504e-19 | False                                   |
| RW25      |          504 | charge (after random walk discharge) | rest post random walk discharge      |        133 |      7871.89 |                 0.13   |                 0.091 |           3.19799e-05 |         -4.24668e-19 | False                                   |
| RW25      |          544 | charge (after random walk discharge) | rest post random walk discharge      |        140 |      8303.32 |                 0.1475 |                 0.155 |           0.00010995  |         -4.01719e-19 | False                                   |
| RW25      |          584 | charge (after random walk discharge) | rest post random walk discharge      |        144 |      8558.99 |                 0.15   |                 0.171 |           0.000136642 |         -8.02896e-19 | False                                   |
| RW25      |          616 | charge (after random walk discharge) | rest post random walk discharge      |        132 |      7857.22 |                 0.1275 |                 0.091 |           3.25439e-05 |         -5.36343e-20 | False                                   |
| RW25      |          652 | charge (after random walk discharge) | rest post random walk discharge      |        138 |      8165.97 |                 0.134  |                 0.138 |           7.89098e-05 |          1.00814e-18 | False                                   |
| RW25      |          696 | charge (after random walk discharge) | rest post random walk discharge      |        142 |      8427.93 |                 0.153  |                 0.17  |           0.000134386 |         -5.31791e-19 | False                                   |
| RW25      |          740 | charge (after random walk discharge) | rest post random walk discharge      |        142 |      8415.86 |                 0.1435 |                 0.168 |           0.000130965 |         -6.6757e-20  | False                                   |
| RW25      |          774 | charge (after random walk discharge) | rest post random walk discharge      |        132 |      7853.53 |                 0.1295 |                 0.107 |           4.36216e-05 |          7.53532e-19 | False                                   |
| RW25      |          808 | charge (after random walk discharge) | rest post random walk discharge      |        135 |      7993.45 |                 0.129  |                 0.129 |           6.59148e-05 |          5.0099e-19  | False                                   |
| RW25      |          866 | charge (after random walk discharge) | rest post random walk discharge      |        155 |      9212.86 |                 0.176  |                 0.214 |           0.000137068 |         -1.14618e-18 | False                                   |
| RW25      |          906 | charge (after random walk discharge) | rest post random walk discharge      |        142 |      8433.45 |                 0.1405 |                 0.164 |           0.000124311 |         -1.79646e-19 | False                                   |
| RW25      |          946 | charge (after random walk discharge) | rest post random walk discharge      |        143 |      8466.38 |                 0.143  |                 0.168 |           0.000131642 |         -1.38986e-20 | False                                   |
| RW25      |          988 | charge (after random walk discharge) | rest post random walk discharge      |        143 |      8508.03 |                 0.147  |                 0.172 |           0.000137707 |          7.49522e-19 | False                                   |
| RW25      |         1024 | charge (after random walk discharge) | rest post random walk discharge      |        138 |      8215.76 |                 0.136  |                 0.144 |           8.85589e-05 |         -7.03951e-19 | False                                   |
| RW25      |         1058 | charge (after random walk discharge) | rest post random walk discharge      |        132 |      7859.53 |                 0.126  |                 0.101 |           4.04386e-05 |         -4.59888e-19 | False                                   |
| RW25      |         1094 | charge (after random walk discharge) | rest post random walk discharge      |        133 |      7917.71 |                 0.134  |                 0.122 |           5.72932e-05 |          6.26123e-19 | False                                   |
| RW25      |         1146 | charge (after random walk discharge) | rest post random walk discharge      |        149 |      8842.69 |                 0.161  |                 0.199 |           0.000158396 |          4.03476e-20 | False                                   |
| RW25      |         1190 | charge (after random walk discharge) | rest post random walk discharge      |        144 |      8537.76 |                 0.1495 |                 0.181 |           0.000148333 |         -1.62546e-19 | False                                   |
| RW25      |         1224 | charge (after random walk discharge) | rest post random walk discharge      |        138 |      8178.24 |                 0.1305 |                 0.142 |           8.55263e-05 |         -9.11673e-19 | False                                   |
| RW25      |         1260 | charge (after random walk discharge) | rest post random walk discharge      |        133 |      7912.93 |                 0.131  |                 0.118 |           5.18421e-05 |          8.03915e-19 | False                                   |
| RW25      |         1306 | charge (after random walk discharge) | rest post random walk discharge      |        144 |      8564.78 |                 0.1475 |                 0.18  |           0.000147343 |         -9.2363e-20  | False                                   |
| RW25      |         1350 | charge (after random walk discharge) | rest post random walk discharge      |        146 |      8641.36 |                 0.14   |                 0.179 |           0.000145965 |         -6.22167e-19 | False                                   |
| RW25      |         1388 | charge (after random walk discharge) | rest post random walk discharge      |        138 |      8219.03 |                 0.1355 |                 0.149 |           9.68922e-05 |         -4.48221e-20 | False                                   |
| RW25      |         1434 | charge (after random walk discharge) | rest post random walk discharge      |        144 |      8536.6  |                 0.154  |                 0.185 |           0.00015287  |          3.53631e-19 | False                                   |


## Interpretation guardrail

These outputs establish whether explicit rest-prior-reference-discharge steps contain measurable voltage-time-current descriptors. They should be interpreted as relaxation-state or polarization-recovery descriptors only, not as direct evidence of SEI growth, loss of active material, or a named overpotential mechanism without additional physical validation.