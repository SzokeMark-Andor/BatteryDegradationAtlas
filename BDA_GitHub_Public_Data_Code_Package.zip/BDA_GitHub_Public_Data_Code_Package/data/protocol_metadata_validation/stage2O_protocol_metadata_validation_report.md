# Stage 2O Public-validation-Hardening Experimental Robustness Report

Generated: 2026-05-06T22:05:58


## Summary

{
  "outdir": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448",
  "analysis_csv": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_rest_reference_capacity_analysis_table.csv",
  "n_rows": 294,
  "n_cells": 16,
  "n_conditions": 4,
  "n_perm": 200,
  "best_delta_vs_sequence_condition": -0.004294713871956803,
  "best_delta_ci95_low": -0.007666820506705265,
  "best_delta_ci95_high": -0.0007981025242206751,
  "noise_control_delta": 0.0014726159818900329,
  "shuffled_control_delta": -0.00021763274298131595,
  "permutation_empirical_p": 0.0,
  "alternative_soh_target_delta": -0.0030822353320350787,
  "best_residual_abs_spearman": 0.47975817619232575,
  "best_residual_feature": "prev_charge_median_abs_current_A",
  "manuscript_strength": "protocol_metadata_validated_moderate_predictive_increment",
  "outputs": {
    "prediction_summary": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448\\stage2O_prediction_summary.csv",
    "delta_summary": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448\\stage2O_delta_summary_vs_sequence_condition.csv",
    "permutation_summary": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448\\stage2O_permutation_null_summary.csv",
    "condition_holdout_summary": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448\\stage2O_leave_one_condition_out_summary.csv",
    "residual_sensitivity": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448\\stage2O_sequence_residual_degree_sensitivity.csv",
    "interpretation_flags": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448\\stage2O_interpretation_flags.csv",
    "latex_insert": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448\\stage2O_protocol_metadata_validation_insert.tex",
    "figures": "C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448\\figures"
  }
}


## Interpretation flags

| question                                                                | answer                                          | evidence                                                                                                 |
|:------------------------------------------------------------------------|:------------------------------------------------|:---------------------------------------------------------------------------------------------------------|
| Does the descriptor block improve over the sequence+condition baseline? | yes                                             | mean delta=-0.00429, 95% bootstrap CI=[-0.00767,-0.00080], improved folds=0.75, Wilcoxon p=0.0107        |
| Does the descriptor block beat noise and shuffled controls?             | yes                                             | descriptor delta=-0.00429; noise delta=0.00147; shuffled delta=-0.00022                                  |
| Does descriptor permutation support non-random predictive increment?    | yes                                             | observed delta=-0.00429; null mean=-0.00033; empirical p=0.0000                                          |
| Does the result survive alternative SOH normalization?                  | yes                                             | first-reference SOH target delta=-0.00308                                                                |
| Does local residual evidence become mechanistically strong?             | yes/inspect carefully                           | best residual |Spearman|=0.480 for prev_charge_median_abs_current_A, sequence residual degree=1          |
| Recommended manuscript strength                                         | protocol_metadata_validated_moderate_predictive_increment | Use this label to decide whether Stage 2O should enter the main article or only the main text or supplement. |


## Delta summary vs sequence+condition baseline

| target                        | feature_set                                 |   n_folds |   mean_delta_mae |     ci95_low |    ci95_high |   median_delta_mae |   fraction_folds_improved |   wilcoxon_p_less_than_baseline |
|:------------------------------|:--------------------------------------------|----------:|-----------------:|-------------:|-------------:|-------------------:|--------------------------:|--------------------------------:|
| reference_soh                 | sequence_condition_plus_rest_plus_charge    |        16 |     -0.00429471  | -0.00766682  | -0.000798103 |       -0.00405887  |                    0.75   |                      0.0106964  |
| reference_soh                 | sequence_condition_plus_charge              |        16 |     -0.00403708  | -0.00765321  |  0.000100761 |       -0.00420344  |                    0.8125 |                      0.0193176  |
| reference_soh                 | sequence_plus_rest_plus_charge_no_condition |        16 |     -0.00387775  | -0.00842779  |  0.000525959 |       -0.00266547  |                    0.8125 |                      0.00775146 |
| reference_soh                 | sequence_condition_plus_rest                |        16 |     -0.000460163 | -0.00141372  |  0.000698003 |       -0.000929152 |                    0.6875 |                      0.105713   |
| reference_soh                 | sequence_condition_plus_shuffled            |        16 |     -0.000217633 | -0.00152405  |  0.00111697  |       -0.00019071  |                    0.5    |                      0.352859   |
| reference_soh                 | sequence_condition_plus_noise               |        16 |      0.00147262  |  0.000568125 |  0.00248222  |        0.00151839  |                    0.25   |                      0.997421   |
| reference_soh                 | sequence_only                               |        16 |      0.0050099   | -0.00347304  |  0.0130549   |        0.00794502  |                    0.25   |                      0.894287   |
| reference_soh_first_reference | sequence_condition_plus_rest_plus_charge    |        16 |     -0.00308224  | -0.0059659   | -0.000134921 |       -0.00359173  |                    0.6875 |                      0.041626   |
| reference_soh_first_reference | sequence_condition_plus_charge              |        16 |     -0.00216701  | -0.00549     |  0.00139593  |       -0.00363654  |                    0.625  |                      0.105713   |
| reference_soh_first_reference | sequence_plus_rest_plus_charge_no_condition |        16 |     -0.00158533  | -0.00576673  |  0.00185227  |        0.000950727 |                    0.4375 |                      0.449966   |
| reference_soh_first_reference | sequence_condition_plus_rest                |        16 |     -0.000678865 | -0.00151857  |  7.0932e-05  |       -0.000763863 |                    0.6875 |                      0.0719299  |
| reference_soh_first_reference | sequence_condition_plus_shuffled            |        16 |      0.00122446  |  0.000255675 |  0.00248351  |        0.000907243 |                    0.3125 |                      0.977844   |
| reference_soh_first_reference | sequence_condition_plus_noise               |        16 |      0.00141804  |  0.000368057 |  0.00245004  |        0.00162134  |                    0.1875 |                      0.993454   |
| reference_soh_first_reference | sequence_only                               |        16 |      0.00588598  | -0.00209845  |  0.013438    |        0.00725868  |                    0.25   |                      0.947708   |


## Permutation null summary

|   n_perm |   observed_delta_mae |   null_mean_delta_mae |   null_ci95_low |   null_ci95_high |   empirical_p_null_delta_le_observed |
|---------:|---------------------:|----------------------:|----------------:|-----------------:|-------------------------------------:|
|      200 |          -0.00429471 |          -0.000327418 |     -0.00132618 |      0.000616184 |                                    0 |


## Leave-one-condition-out sanity check

| target        | feature_set                    |   n_folds |   mean_delta_mae |    ci95_low |    ci95_high |   median_delta_mae |   fraction_folds_improved |   wilcoxon_p_less_than_baseline |
|:--------------|:-------------------------------|----------:|-----------------:|------------:|-------------:|-------------------:|--------------------------:|--------------------------------:|
| reference_soh | sequence_plus_rest_plus_charge |         4 |      -0.0119923  | -0.0225504  | -0.00528315  |        -0.00814339 |                      1    |                             nan |
| reference_soh | sequence_plus_charge           |         4 |      -0.00840866 | -0.0164358  | -0.000566743 |        -0.00822342 |                      0.75 |                             nan |
| reference_soh | sequence_plus_rest             |         4 |      -0.00521296 | -0.00809743 | -0.0023285   |        -0.00565696 |                      1    |                             nan |


## Public-validation-safe conclusion

Use Stage 2O in the article only if the results remain supportive. The desired claim is not mechanistic proof; it is a validated metadata-preservation and prognostic-alignment claim.