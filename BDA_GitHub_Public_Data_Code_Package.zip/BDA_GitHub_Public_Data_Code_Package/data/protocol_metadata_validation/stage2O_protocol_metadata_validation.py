from pathlib import Path
import json
import math
import warnings
from datetime import datetime

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

ANALYSIS_CSV = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2F_rest_to_capacity_20260505_144705\\stage2F_rest_reference_capacity_analysis_table.csv")
OUTDIR = Path(r"C:\\Users\\szoke\\Documents\\BatteryDegradationAtlas\\reports\\analysis_build_stage2O_protocol_metadata_validation_20260506_220448")
FIGDIR = OUTDIR / "figures"
OUTDIR.mkdir(parents=True, exist_ok=True)
FIGDIR.mkdir(exist_ok=True)

RNG = np.random.default_rng(42)

print("Loading libraries...", flush=True)

try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except Exception as e:
    HAS_MPL = False
    MPL_ERROR = str(e)

try:
    from scipy.stats import wilcoxon, spearmanr
    HAS_SCIPY = True
except Exception:
    HAS_SCIPY = False

try:
    from sklearn.base import clone
    from sklearn.model_selection import LeaveOneGroupOut
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import Ridge
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    HAS_SKLEARN = True
except Exception as e:
    HAS_SKLEARN = False
    SKLEARN_ERROR = str(e)


def condition_from_cell(cell):
    try:
        n = int(str(cell).replace("RW", ""))
    except Exception:
        return "unknown"
    if 13 <= n <= 16:
        return "low_skew_room_temp"
    if 17 <= n <= 20:
        return "high_skew_room_temp"
    if 21 <= n <= 24:
        return "low_skew_40C"
    if 25 <= n <= 28:
        return "high_skew_40C"
    return "unknown"


def rmse(y_true, y_pred):
    return float(math.sqrt(mean_squared_error(y_true, y_pred)))


def safe_spearman(x, y):
    x = pd.to_numeric(pd.Series(x), errors="coerce")
    y = pd.to_numeric(pd.Series(y), errors="coerce")
    m = x.notna() & y.notna()
    if m.sum() < 8 or x[m].nunique() < 3 or y[m].nunique() < 3:
        return np.nan
    if HAS_SCIPY:
        return float(spearmanr(x[m], y[m]).correlation)
    return float(x[m].rank().corr(y[m].rank()))


def bootstrap_ci(vals, n_boot=4000, seed=42):
    vals = np.asarray(vals, dtype=float)
    vals = vals[np.isfinite(vals)]
    if len(vals) == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    means = []
    for _ in range(n_boot):
        samp = rng.choice(vals, size=len(vals), replace=True)
        means.append(float(np.mean(samp)))
    means = np.asarray(means)
    return float(np.mean(vals)), float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def build_X(df, cols, include_condition=False, prefix=""):
    X = pd.DataFrame(index=df.index)

    for c in cols:
        if c in df.columns:
            X[prefix + c] = pd.to_numeric(df[c], errors="coerce")

    if include_condition:
        dummies = pd.get_dummies(df["condition_group"].astype(str), prefix="condition", dtype=float)
        X = pd.concat([X, dummies], axis=1)

    return X.replace([np.inf, -np.inf], np.nan)


def loo_eval(df, feature_sets, y_col="reference_soh", group_col="cell_id", verbose=True):
    if not HAS_SKLEARN:
        raise RuntimeError(f"sklearn unavailable: {SKLEARN_ERROR}")

    work = df.dropna(subset=[y_col, group_col]).copy()
    y = pd.to_numeric(work[y_col], errors="coerce").astype(float)
    groups = work[group_col].astype(str)

    model = make_pipeline(
        SimpleImputer(strategy="median"),
        StandardScaler(),
        Ridge(alpha=1.0)
    )

    logo = LeaveOneGroupOut()

    summary_rows = []
    fold_rows = []

    for fs_name, cfg in feature_sets.items():
        if verbose:
            print(f"  LOO {y_col}: {fs_name}", flush=True)

        X = build_X(
            work,
            cfg.get("cols", []),
            include_condition=cfg.get("include_condition", False),
            prefix=cfg.get("prefix", "")
        )

        nonempty = [c for c in X.columns if X[c].notna().any()]
        X = X[nonempty]

        if X.shape[1] == 0:
            summary_rows.append({
                "status": "skipped",
                "target": y_col,
                "feature_set": fs_name,
                "reason": "no usable features"
            })
            continue

        preds = np.full(len(work), np.nan)

        for fold_id, (train_idx, test_idx) in enumerate(logo.split(X, y, groups)):
            est = clone(model)
            est.fit(X.iloc[train_idx], y.iloc[train_idx])
            pred = est.predict(X.iloc[test_idx])
            preds[test_idx] = pred

            held = str(groups.iloc[test_idx].iloc[0])
            fold_rows.append({
                "target": y_col,
                "feature_set": fs_name,
                "fold_id": int(fold_id),
                "held_out": held,
                "fold_mae": float(mean_absolute_error(y.iloc[test_idx], pred)),
                "fold_rmse": rmse(y.iloc[test_idx], pred),
                "n_test": int(len(test_idx)),
                "n_features": int(X.shape[1]),
            })

        m = np.isfinite(preds)
        summary_rows.append({
            "status": "ok",
            "target": y_col,
            "feature_set": fs_name,
            "model": "ridge",
            "mae": float(mean_absolute_error(y[m], preds[m])),
            "rmse": rmse(y[m], preds[m]),
            "r2": float(r2_score(y[m], preds[m])),
            "n_rows": int(m.sum()),
            "n_groups": int(groups.nunique()),
            "n_features": int(X.shape[1]),
        })

    return pd.DataFrame(summary_rows), pd.DataFrame(fold_rows)


def delta_vs_baseline(folds, baseline_name):
    rows = []
    base = folds[folds["feature_set"] == baseline_name].copy()
    for (target, held), bg in base.groupby(["target", "held_out"]):
        base_mae = float(bg["fold_mae"].iloc[0])
        cand = folds[
            (folds["target"] == target) &
            (folds["held_out"] == held) &
            (folds["feature_set"] != baseline_name)
        ]
        for _, r in cand.iterrows():
            rows.append({
                "target": target,
                "feature_set": r["feature_set"],
                "held_out": held,
                "baseline": baseline_name,
                "baseline_fold_mae": base_mae,
                "candidate_fold_mae": float(r["fold_mae"]),
                "delta_mae": float(r["fold_mae"] - base_mae),
            })
    return pd.DataFrame(rows)


def summarize_delta(delta):
    rows = []
    if len(delta) == 0:
        return pd.DataFrame()

    for (target, fs), g in delta.groupby(["target", "feature_set"]):
        vals = g["delta_mae"].dropna().to_numpy(dtype=float)
        mean, lo, hi = bootstrap_ci(vals, n_boot=4000, seed=42)

        p_w = np.nan
        if HAS_SCIPY and len(vals) >= 6 and len(np.unique(vals)) > 1:
            try:
                p_w = float(wilcoxon(vals, alternative="less").pvalue)
            except Exception:
                p_w = np.nan

        rows.append({
            "target": target,
            "feature_set": fs,
            "n_folds": int(len(vals)),
            "mean_delta_mae": mean,
            "ci95_low": lo,
            "ci95_high": hi,
            "median_delta_mae": float(np.median(vals)) if len(vals) else np.nan,
            "fraction_folds_improved": float(np.mean(vals < 0)) if len(vals) else np.nan,
            "wilcoxon_p_less_than_baseline": p_w,
        })

    out = pd.DataFrame(rows)
    if len(out):
        out = out.sort_values(["target", "mean_delta_mae"])
    return out


print("Loading Stage 2F analysis table...", flush=True)
df = pd.read_csv(ANALYSIS_CSV)
df["condition_group"] = df["cell_id"].map(condition_from_cell)

for c in df.columns:
    if c not in ["cell_id", "condition_group"]:
        df[c] = pd.to_numeric(df[c], errors="ignore")

# Alternative SOH target using first reference capacity instead of first-three median.
df = df.sort_values(["cell_id", "rest_sequence_index"]).copy()
first_cap = df.groupby("cell_id")["reference_capacity_Ah"].transform("first")
df["reference_soh_first_reference"] = df["reference_capacity_Ah"] / first_cap

rest_cols = [
    "rest_duration_s",
    "rest_n_points",
    "rest_voltage_start_V",
    "rest_voltage_end_V",
    "rest_delta_voltage_V",
    "rest_abs_delta_voltage_V",
    "rest_abs_delta_voltage_mV",
    "rest_median_abs_current_A",
    "rest_mean_abs_current_A",
]

charge_cols = [
    "prev_charge_duration_s",
    "prev_charge_n_points",
    "prev_charge_delta_voltage_V",
    "prev_charge_abs_delta_voltage_V",
    "prev_charge_median_abs_current_A",
    "prev_charge_mean_abs_current_A",
    "prev_charge_capacity_Ah_abs_current_integral",
]

rest_cols = [c for c in rest_cols if c in df.columns]
charge_cols = [c for c in charge_cols if c in df.columns]
descriptor_cols = rest_cols + charge_cols

sequence_cols = ["rest_sequence_index", "rest_step_index"]
sequence_cols = [c for c in sequence_cols if c in df.columns]

# Noise and shuffled controls.
for k in range(len(descriptor_cols)):
    df[f"noise_{k:02d}"] = RNG.normal(0, 1, len(df))

for c in descriptor_cols:
    s = f"shuf_{c}"
    df[s] = np.nan
    for cell, idx in df.groupby("cell_id").groups.items():
        vals = df.loc[idx, c].to_numpy()
        df.loc[idx, s] = RNG.permutation(vals)

noise_cols = [c for c in df.columns if c.startswith("noise_")]
shuf_cols = [c for c in df.columns if c.startswith("shuf_")]

feature_sets = {
    "sequence_condition": {
        "cols": sequence_cols,
        "include_condition": True,
    },
    "sequence_condition_plus_rest": {
        "cols": sequence_cols + rest_cols,
        "include_condition": True,
    },
    "sequence_condition_plus_charge": {
        "cols": sequence_cols + charge_cols,
        "include_condition": True,
    },
    "sequence_condition_plus_rest_plus_charge": {
        "cols": sequence_cols + rest_cols + charge_cols,
        "include_condition": True,
    },
    "sequence_condition_plus_noise": {
        "cols": sequence_cols + noise_cols,
        "include_condition": True,
    },
    "sequence_condition_plus_shuffled": {
        "cols": sequence_cols + shuf_cols,
        "include_condition": True,
    },
    "sequence_only": {
        "cols": sequence_cols,
        "include_condition": False,
    },
    "sequence_plus_rest_plus_charge_no_condition": {
        "cols": sequence_cols + rest_cols + charge_cols,
        "include_condition": False,
    },
}

print(f"Rows: {len(df)} | cells: {df['cell_id'].nunique()} | conditions: {df['condition_group'].nunique()}", flush=True)
print(f"Descriptor columns: {len(descriptor_cols)}", flush=True)

targets = ["reference_soh", "reference_soh_first_reference"]

all_summary = []
all_folds = []

print("Running leave-one-cell-out ridge validation for target-normalization robustness...", flush=True)
for y_col in targets:
    s, f = loo_eval(df, feature_sets, y_col=y_col, group_col="cell_id", verbose=True)
    all_summary.append(s)
    all_folds.append(f)

prediction_summary = pd.concat(all_summary, ignore_index=True)
fold_metrics = pd.concat(all_folds, ignore_index=True)

prediction_summary.to_csv(OUTDIR / "stage2O_prediction_summary.csv", index=False)
fold_metrics.to_csv(OUTDIR / "stage2O_leave_one_cell_out_fold_metrics.csv", index=False)

delta = delta_vs_baseline(fold_metrics, baseline_name="sequence_condition")
delta.to_csv(OUTDIR / "stage2O_fold_delta_vs_sequence_condition.csv", index=False)

delta_summary = summarize_delta(delta)
delta_summary.to_csv(OUTDIR / "stage2O_delta_summary_vs_sequence_condition.csv", index=False)

print("Running descriptor permutation null with ridge only...", flush=True)
n_perm = 200

obs = delta_summary[
    (delta_summary["target"] == "reference_soh") &
    (delta_summary["feature_set"] == "sequence_condition_plus_rest_plus_charge")
].copy()

if len(obs):
    observed_delta = float(obs.iloc[0]["mean_delta_mae"])
else:
    observed_delta = np.nan

perm_rows = []
for p in range(n_perm):
    if p % 25 == 0:
        print(f"  permutation {p}/{n_perm}", flush=True)

    perm = df.copy()

    perm_cols = []
    for c in descriptor_cols:
        pc = f"perm_{c}"
        perm[pc] = np.nan
        for cell, idx in perm.groupby("cell_id").groups.items():
            vals = perm.loc[idx, c].to_numpy()
            perm.loc[idx, pc] = RNG.permutation(vals)
        perm_cols.append(pc)

    perm_sets = {
        "sequence_condition": {
            "cols": sequence_cols,
            "include_condition": True,
        },
        "sequence_condition_plus_permuted_rest_plus_charge": {
            "cols": sequence_cols + perm_cols,
            "include_condition": True,
        },
    }

    _, pf = loo_eval(perm, perm_sets, y_col="reference_soh", group_col="cell_id", verbose=False)
    pdlt = delta_vs_baseline(pf, baseline_name="sequence_condition")
    psum = summarize_delta(pdlt)

    if len(psum):
        val = float(psum.iloc[0]["mean_delta_mae"])
    else:
        val = np.nan

    perm_rows.append({
        "perm_id": int(p),
        "permutation_delta_mae": val,
    })

perm_df = pd.DataFrame(perm_rows)
perm_df.to_csv(OUTDIR / "stage2O_permutation_null_distribution.csv", index=False)

if len(perm_df) and pd.notna(observed_delta):
    null_vals = perm_df["permutation_delta_mae"].dropna().to_numpy(dtype=float)
    empirical_p = float(np.mean(null_vals <= observed_delta)) if len(null_vals) else np.nan
    null_mean = float(np.mean(null_vals)) if len(null_vals) else np.nan
    null_lo = float(np.quantile(null_vals, 0.025)) if len(null_vals) else np.nan
    null_hi = float(np.quantile(null_vals, 0.975)) if len(null_vals) else np.nan
else:
    empirical_p = np.nan
    null_mean = np.nan
    null_lo = np.nan
    null_hi = np.nan

perm_summary = pd.DataFrame([{
    "n_perm": int(n_perm),
    "observed_delta_mae": observed_delta,
    "null_mean_delta_mae": null_mean,
    "null_ci95_low": null_lo,
    "null_ci95_high": null_hi,
    "empirical_p_null_delta_le_observed": empirical_p,
}])
perm_summary.to_csv(OUTDIR / "stage2O_permutation_null_summary.csv", index=False)

print("Running leave-one-condition-out sanity check...", flush=True)
condition_feature_sets = {
    "sequence_only": {
        "cols": sequence_cols,
        "include_condition": False,
    },
    "sequence_plus_rest": {
        "cols": sequence_cols + rest_cols,
        "include_condition": False,
    },
    "sequence_plus_charge": {
        "cols": sequence_cols + charge_cols,
        "include_condition": False,
    },
    "sequence_plus_rest_plus_charge": {
        "cols": sequence_cols + rest_cols + charge_cols,
        "include_condition": False,
    },
}

condition_summary, condition_folds = loo_eval(
    df,
    condition_feature_sets,
    y_col="reference_soh",
    group_col="condition_group",
    verbose=True
)
condition_summary.to_csv(OUTDIR / "stage2O_leave_one_condition_out_summary.csv", index=False)
condition_folds.to_csv(OUTDIR / "stage2O_leave_one_condition_out_folds.csv", index=False)

condition_delta = delta_vs_baseline(condition_folds, baseline_name="sequence_only")
condition_delta_summary = summarize_delta(condition_delta)
condition_delta_summary.to_csv(OUTDIR / "stage2O_leave_one_condition_out_delta_summary.csv", index=False)

print("Running local deconfounding sanity metrics...", flush=True)
res_rows = []
for degree in [1, 2, 3]:
    for feat in descriptor_cols:
        x_res_all = []
        y_res_all = []

        for cell, g in df.groupby("cell_id"):
            g = g.sort_values("rest_sequence_index")
            x = pd.to_numeric(g[feat], errors="coerce")
            y = pd.to_numeric(g["reference_soh"], errors="coerce")
            t = pd.to_numeric(g["rest_sequence_index"], errors="coerce")
            m = x.notna() & y.notna() & t.notna()

            if m.sum() < degree + 3 or t[m].nunique() < degree + 1:
                continue

            tt = t[m].to_numpy(dtype=float)
            X = np.vstack([tt ** d for d in range(degree + 1)]).T

            try:
                bx, *_ = np.linalg.lstsq(X, x[m].to_numpy(dtype=float), rcond=None)
                by, *_ = np.linalg.lstsq(X, y[m].to_numpy(dtype=float), rcond=None)
                x_res = x[m].to_numpy(dtype=float) - X @ bx
                y_res = y[m].to_numpy(dtype=float) - X @ by
                x_res_all.extend(list(x_res))
                y_res_all.extend(list(y_res))
            except Exception:
                pass

        rho = safe_spearman(x_res_all, y_res_all)
        res_rows.append({
            "sequence_residual_degree": int(degree),
            "feature": feat,
            "spearman_r": rho,
            "abs_spearman_r": abs(rho) if pd.notna(rho) else np.nan,
            "n": int(len(x_res_all)),
        })

residual_sensitivity = pd.DataFrame(res_rows).sort_values(
    ["sequence_residual_degree", "abs_spearman_r"],
    ascending=[True, False]
)
residual_sensitivity.to_csv(OUTDIR / "stage2O_sequence_residual_degree_sensitivity.csv", index=False)

best_delta_row = delta_summary[
    (delta_summary["target"] == "reference_soh") &
    (delta_summary["feature_set"] == "sequence_condition_plus_rest_plus_charge")
].copy()

if len(best_delta_row):
    best_delta = float(best_delta_row.iloc[0]["mean_delta_mae"])
    best_delta_lo = float(best_delta_row.iloc[0]["ci95_low"])
    best_delta_hi = float(best_delta_row.iloc[0]["ci95_high"])
    best_improved = float(best_delta_row.iloc[0]["fraction_folds_improved"])
    best_wilcoxon = float(best_delta_row.iloc[0]["wilcoxon_p_less_than_baseline"])
else:
    best_delta = np.nan
    best_delta_lo = np.nan
    best_delta_hi = np.nan
    best_improved = np.nan
    best_wilcoxon = np.nan

noise_row = delta_summary[
    (delta_summary["target"] == "reference_soh") &
    (delta_summary["feature_set"] == "sequence_condition_plus_noise")
].copy()
noise_delta = float(noise_row.iloc[0]["mean_delta_mae"]) if len(noise_row) else np.nan

shuf_row = delta_summary[
    (delta_summary["target"] == "reference_soh") &
    (delta_summary["feature_set"] == "sequence_condition_plus_shuffled")
].copy()
shuf_delta = float(shuf_row.iloc[0]["mean_delta_mae"]) if len(shuf_row) else np.nan

first_target_row = delta_summary[
    (delta_summary["target"] == "reference_soh_first_reference") &
    (delta_summary["feature_set"] == "sequence_condition_plus_rest_plus_charge")
].copy()
first_target_delta = float(first_target_row.iloc[0]["mean_delta_mae"]) if len(first_target_row) else np.nan

best_res = residual_sensitivity.dropna(subset=["abs_spearman_r"]).sort_values("abs_spearman_r", ascending=False).head(1)
if len(best_res):
    best_res_abs = float(best_res.iloc[0]["abs_spearman_r"])
    best_res_feat = str(best_res.iloc[0]["feature"])
    best_res_degree = int(best_res.iloc[0]["sequence_residual_degree"])
else:
    best_res_abs = np.nan
    best_res_feat = ""
    best_res_degree = -1

if pd.notna(best_delta) and best_delta < 0 and pd.notna(noise_delta) and pd.notna(shuf_delta) and best_delta < noise_delta and best_delta < shuf_delta and pd.notna(empirical_p) and empirical_p <= 0.05:
    strength = "protocol_metadata_validated_moderate_predictive_increment"
elif pd.notna(best_delta) and best_delta < 0:
    strength = "weak_to_moderate_predictive_increment"
else:
    strength = "mostly_sequence_protocol_alignment"

interpretation = pd.DataFrame([
    {
        "question": "Does the descriptor block improve over the sequence+condition baseline?",
        "answer": "yes" if pd.notna(best_delta) and best_delta < 0 else "no/unclear",
        "evidence": f"mean delta={best_delta:.5f}, 95% bootstrap CI=[{best_delta_lo:.5f},{best_delta_hi:.5f}], improved folds={best_improved:.2f}, Wilcoxon p={best_wilcoxon:.4f}" if pd.notna(best_delta) else "not available",
    },
    {
        "question": "Does the descriptor block beat noise and shuffled controls?",
        "answer": "yes" if pd.notna(best_delta) and pd.notna(noise_delta) and pd.notna(shuf_delta) and best_delta < noise_delta and best_delta < shuf_delta else "no/unclear",
        "evidence": f"descriptor delta={best_delta:.5f}; noise delta={noise_delta:.5f}; shuffled delta={shuf_delta:.5f}",
    },
    {
        "question": "Does descriptor permutation support non-random predictive increment?",
        "answer": "yes" if pd.notna(empirical_p) and empirical_p <= 0.05 else "no/unclear",
        "evidence": f"observed delta={observed_delta:.5f}; null mean={null_mean:.5f}; empirical p={empirical_p:.4f}" if pd.notna(empirical_p) else "not available",
    },
    {
        "question": "Does the result survive alternative SOH normalization?",
        "answer": "yes" if pd.notna(first_target_delta) and first_target_delta < 0 else "no/unclear",
        "evidence": f"first-reference SOH target delta={first_target_delta:.5f}" if pd.notna(first_target_delta) else "not available",
    },
    {
        "question": "Does local residual evidence become mechanistically strong?",
        "answer": "weak/no" if pd.notna(best_res_abs) and best_res_abs < 0.30 else "yes/inspect carefully",
        "evidence": f"best residual |Spearman|={best_res_abs:.3f} for {best_res_feat}, sequence residual degree={best_res_degree}" if pd.notna(best_res_abs) else "not available",
    },
    {
        "question": "Recommended manuscript strength",
        "answer": strength,
        "evidence": "Use this label to decide whether Stage 2O should enter the main article or only the main text or supplement.",
    },
])
interpretation.to_csv(OUTDIR / "stage2O_interpretation_flags.csv", index=False)

print("Generating figures...", flush=True)
if HAS_MPL:
    plt.rcParams.update({
        "figure.dpi": 180,
        "savefig.dpi": 600,
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })

    fig, axes = plt.subplots(1, 3, figsize=(14.5, 4.6))

    ax = axes[0]
    plot_sets = [
        "sequence_condition_plus_rest_plus_charge",
        "sequence_condition_plus_charge",
        "sequence_condition_plus_rest",
        "sequence_condition_plus_shuffled",
        "sequence_condition_plus_noise",
        "sequence_only",
    ]
    q = delta_summary[
        (delta_summary["target"] == "reference_soh") &
        (delta_summary["feature_set"].isin(plot_sets))
    ].copy()
    q = q.set_index("feature_set").reindex(plot_sets).reset_index().dropna(subset=["mean_delta_mae"])
    labels = [
        "Seq.+cond.+rest+charge",
        "Seq.+cond.+charge",
        "Seq.+cond.+rest",
        "Seq.+cond.+shuffled",
        "Seq.+cond.+noise",
        "Sequence only",
    ][:len(q)]
    y = np.arange(len(q))
    vals = q["mean_delta_mae"].to_numpy(dtype=float)
    lo = q["ci95_low"].to_numpy(dtype=float)
    hi = q["ci95_high"].to_numpy(dtype=float)
    xerr = np.vstack([vals - lo, hi - vals])
    colors = ["#2ca02c" if v < 0 else "#d62728" for v in vals]
    ax.barh(y, vals, color=colors, alpha=0.88)
    ax.errorbar(vals, y, xerr=xerr, fmt="none", ecolor="black", capsize=2, linewidth=0.8)
    ax.axvline(0, color="black", linewidth=0.9)
    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.invert_yaxis()
    ax.set_xlabel("Mean fold ΔMAE vs sequence+condition")
    ax.set_title("A. Conservative held-out-cell baseline")
    ax.grid(axis="x", alpha=0.18)
    for yi, v in zip(y, vals):
        offset = -0.00025 if v < 0 else 0.00025
        ha = "right" if v < 0 else "left"
        ax.text(v + offset, yi, f"{v:.4f}", va="center", ha=ha, fontsize=7)

    ax = axes[1]
    null_vals = perm_df["permutation_delta_mae"].dropna().to_numpy(dtype=float)
    if len(null_vals):
        ax.hist(null_vals, bins=18, alpha=0.8)
        ax.axvline(observed_delta, color="#d62728", linewidth=2, label=f"Observed {observed_delta:.4f}")
        ax.axvline(0, color="black", linestyle="--", linewidth=1, label="No improvement")
        ax.set_xlabel("Permutation-null mean fold ΔMAE")
        ax.set_ylabel("Count")
        ax.set_title(f"B. Descriptor permutation null, p={empirical_p:.3f}")
        ax.legend(frameon=False)
        ax.grid(axis="y", alpha=0.18)

    ax = axes[2]
    q = residual_sensitivity.dropna(subset=["abs_spearman_r"]).copy()
    top_feats = q.groupby("feature")["abs_spearman_r"].max().sort_values(ascending=False).head(6).index.tolist()
    for feat in top_feats:
        g = q[q["feature"] == feat].sort_values("sequence_residual_degree")
        ax.plot(
            g["sequence_residual_degree"],
            g["abs_spearman_r"],
            marker="o",
            linewidth=1.4,
            label=feat.replace("_", " ")
        )
    ax.axhline(0.30, color="black", linestyle="--", linewidth=1, label="|ρ| = 0.30")
    ax.set_xticks([1, 2, 3])
    ax.set_xlabel("Within-cell sequence residual degree")
    ax.set_ylabel("Residual |Spearman ρ|")
    ax.set_title("C. Mechanistic guardrail remains")
    ax.grid(alpha=0.18)
    ax.legend(frameon=False, fontsize=6)

    fig.suptitle("Stage 2O protocol-metadata robustness-validation robustness checks", fontsize=13, y=1.02)
    fig.tight_layout()

    fig.savefig(FIGDIR / "fig_stage2O_protocol_metadata_validation.pdf", bbox_inches="tight")
    fig.savefig(FIGDIR / "fig_stage2O_protocol_metadata_validation.png", dpi=600, bbox_inches="tight")
    plt.close(fig)

# Optional LaTeX insert.
insert = f"""
% Auto-generated Stage 2O protocol-metadata robustness-validation insert.
% Include only if you want the extra robustness in the main article.

\\subsection{{Protocol-metadata robustness-validation robustness checks}}
\\label{{sec:stage2O_protocol_metadata_validation}}

To further reduce the risk that the rest/reference result is an artifact of condition grouping or target normalization, an additional protocol-metadata robustness-validation analysis was performed using only the derived Stage~2F rest/reference table. The baseline was strengthened from sequence alone to sequence plus randomized-use condition. Under this conservative baseline, the combined rest/pre-reference descriptor block improved leave-one-cell-out prediction by mean fold $\\Delta\\mathrm{{MAE}}={best_delta:.5f}$, with bootstrap 95\\% CI $[{best_delta_lo:.5f},{best_delta_hi:.5f}]$ and improvement in {best_improved:.2f} of held-out cell folds. The effect was not reproduced by noise or within-cell shuffled descriptor controls ($\\Delta\\mathrm{{MAE}}={noise_delta:.5f}$ and {shuf_delta:.5f}, respectively). A descriptor-permutation null test gave observed $\\Delta\\mathrm{{MAE}}={observed_delta:.5f}$ against a null mean of {null_mean:.5f} and empirical $p={empirical_p:.4f}$. The same analysis preserved the mechanistic guardrail: the strongest residual descriptor--SOH association after within-cell sequence residualization was only $|\\rho|={best_res_abs:.3f}$. Therefore, the robust conclusion remains a metadata-dependent predictive increment, not direct evidence for a unique degradation mechanism.

\\begin{{figure*}}[t]
\\centering
\\includegraphics[width=\\textwidth]{{fig_stage2O_protocol_metadata_validation.pdf}}
\\caption{{Protocol-metadata robustness-validation robustness checks. Panel A compares descriptor-augmented models against a conservative sequence+condition baseline using bootstrap confidence intervals over held-out cells. Panel B shows a descriptor-permutation null distribution. Panel C shows that sequence-residual descriptor associations remain below a mechanism-strength threshold.}}
\\label{{fig:stage2O_protocol_metadata_validation}}
\\end{{figure*}}
""".strip()

(Path(OUTDIR) / "stage2O_protocol_metadata_validation_insert.tex").write_text(insert, encoding="utf-8")

summary = {
    "outdir": str(OUTDIR),
    "analysis_csv": str(ANALYSIS_CSV),
    "n_rows": int(len(df)),
    "n_cells": int(df["cell_id"].nunique()),
    "n_conditions": int(df["condition_group"].nunique()),
    "n_perm": int(n_perm),
    "best_delta_vs_sequence_condition": None if pd.isna(best_delta) else best_delta,
    "best_delta_ci95_low": None if pd.isna(best_delta_lo) else best_delta_lo,
    "best_delta_ci95_high": None if pd.isna(best_delta_hi) else best_delta_hi,
    "noise_control_delta": None if pd.isna(noise_delta) else noise_delta,
    "shuffled_control_delta": None if pd.isna(shuf_delta) else shuf_delta,
    "permutation_empirical_p": None if pd.isna(empirical_p) else empirical_p,
    "alternative_soh_target_delta": None if pd.isna(first_target_delta) else first_target_delta,
    "best_residual_abs_spearman": None if pd.isna(best_res_abs) else best_res_abs,
    "best_residual_feature": best_res_feat,
    "manuscript_strength": strength,
    "outputs": {
        "prediction_summary": str(OUTDIR / "stage2O_prediction_summary.csv"),
        "delta_summary": str(OUTDIR / "stage2O_delta_summary_vs_sequence_condition.csv"),
        "permutation_summary": str(OUTDIR / "stage2O_permutation_null_summary.csv"),
        "condition_holdout_summary": str(OUTDIR / "stage2O_leave_one_condition_out_summary.csv"),
        "residual_sensitivity": str(OUTDIR / "stage2O_sequence_residual_degree_sensitivity.csv"),
        "interpretation_flags": str(OUTDIR / "stage2O_interpretation_flags.csv"),
        "latex_insert": str(OUTDIR / "stage2O_protocol_metadata_validation_insert.tex"),
        "figures": str(FIGDIR),
    },
}

with open(OUTDIR / "stage2O_summary.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

report = []
report.append("# Stage 2O Public-validation-Hardening Experimental Robustness Report\n")
report.append(f"Generated: {datetime.now().isoformat(timespec='seconds')}\n")
report.append("\n## Summary\n")
report.append(json.dumps(summary, indent=2))
report.append("\n\n## Interpretation flags\n")
report.append(interpretation.to_markdown(index=False))
report.append("\n\n## Delta summary vs sequence+condition baseline\n")
report.append(delta_summary.to_markdown(index=False))
report.append("\n\n## Permutation null summary\n")
report.append(perm_summary.to_markdown(index=False))
report.append("\n\n## Leave-one-condition-out sanity check\n")
report.append(condition_delta_summary.to_markdown(index=False) if len(condition_delta_summary) else "No condition-holdout deltas.")
report.append("\n\n## Public-validation-safe conclusion\n")
report.append("Use Stage 2O in the article only if the results remain supportive. The desired claim is not mechanistic proof; it is a validated metadata-preservation and prognostic-alignment claim.")
(Path(OUTDIR) / "stage2O_protocol_metadata_validation_report.md").write_text("\n".join(report), encoding="utf-8")

print("\n=== STAGE 2O SUMMARY ===", flush=True)
print(json.dumps(summary, indent=2), flush=True)

print("\n=== INTERPRETATION FLAGS ===", flush=True)
print(interpretation.to_string(index=False), flush=True)

print("\n=== DELTA SUMMARY VS SEQUENCE+CONDITION BASELINE ===", flush=True)
print(delta_summary.to_string(index=False), flush=True)

print("\n=== PERMUTATION NULL SUMMARY ===", flush=True)
print(perm_summary.to_string(index=False), flush=True)

print("\nDONE", flush=True)
print(OUTDIR, flush=True)
