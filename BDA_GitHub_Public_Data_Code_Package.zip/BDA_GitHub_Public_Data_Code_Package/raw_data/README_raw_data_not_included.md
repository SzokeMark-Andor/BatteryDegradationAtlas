# Raw data are not included

This repository package contains derived descriptor tables, scripts, analysis outputs, and manuscript figures.
It intentionally does not include the original NASA PCoE randomized-use MAT files or any other large third-party raw archives.

Reasons:
- Raw battery data are large and should not be duplicated in normal Git history.
- Users should retrieve third-party raw data from the original source and cite that source directly.
- The included Stage 2E/2F/2G/2K/2O derived tables are sufficient to audit the manuscript-level statistical claims and reproduce the public reproducibility analyses.

Suggested workflow for full raw-data reproduction:
1. Download the original NASA PCoE randomized battery usage dataset from the official source.
2. Place the raw MAT files in a local data/raw/ directory that is ignored by Git.
3. Run scripts/stage2E_v3_fresh_rw_rest_extractor.py to rebuild the derived Stage 2E tables.
4. Run the Stage 2F, 2G, 2K, and 2O scripts in order.
