# Battery Degradation Atlas: Public Data and Code Package

This repository package contains the public, reproducibility-focused data and code needed to audit the article-level analyses on data representation, protocol metadata, and battery prognostic signals.

The package is intentionally limited to public scientific artifacts:

- processed Stage 2 analysis tables derived from public battery datasets;
- Python scripts used for extraction, rest/reference alignment, deconfounding, and held-out-cell validation;
- article-level and supplementary figures generated from the processed tables;
- reproducibility and data-availability notes;
- checksums and a file manifest.

It intentionally excludes private correspondence, submission-only documents, build ZIPs, failed build archives, raw third-party MAT files, local caches, and machine-specific temporary outputs.

## Main public evidence

- Explicit rest/reference alignment produced 294 clean adjacent pairs across 16 NASA randomized-use cells.
- Protocol-aware metadata enabled pairing of rest-before-reference-discharge descriptors with reference-discharge capacity benchmarks.
- Deconfounding showed that raw rest-descriptor association is largely aligned with age/protocol sequence.
- Held-out-cell validation showed a modest incremental prognostic benefit from preserved step metadata.
- Noise, shuffled-descriptor, permutation-null, and alternative-SOH checks are included as processed outputs.

## Repository layout

```text
.
├── README.md
├── RUN_REPRODUCIBILITY.md
├── DATA_AVAILABILITY.md
├── CITATION.cff
├── requirements.txt
├── data/
│   ├── stage2E_step_comment_extraction/
│   ├── stage2F_rest_reference_alignment/
│   ├── stage2G_deconfounding/
│   └── protocol_metadata_validation/
├── figures/
│   ├── main_article/
│   └── supplementary/
├── scripts/
├── raw_data/
└── metadata/
```

## What to upload to GitHub

Upload this cleaned package only. Do not upload raw NASA MAT archives, old submission ZIPs, private correspondence files, or empty/failed build archives.

## License note

A public repository should include a license before release. A `LICENSE_TO_BE_SELECTED_BY_AUTHOR.md` note is included because the final license must be selected by the repository owner.
